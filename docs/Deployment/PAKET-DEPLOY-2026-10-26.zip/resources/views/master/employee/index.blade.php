﻿@extends('dashboard')

@section('title', 'Master Employee')
@section('page-title', 'Employee Management')

@section('content')
{{-- Brand colour of this page follows Settings → Appearance (Accent colour), like the sidebar. --}}
@include('partials.accent-brand-red')
<script>
const canEmployeeAction = {{ $can('master.employee.action') ? 'true' : 'false' }};
</script>
@php
    // Kartu ringkasan (gaya sama dengan External → Consultants): klik kartu = terapkan filter pada daftar di bawah.
    $tones = ['blue' => 'bg-blue-50 text-blue-600', 'green' => 'bg-green-50 text-green-600', 'amber' => 'bg-amber-50 text-amber-600', 'red' => 'bg-red-50 text-red-600', 'gray' => 'bg-gray-100 text-gray-500'];
    $cards = [
        ['all', 'Total employees', $summary['total'] ?? 0, 'users', 'blue', []],
        ['active', 'Active', $summary['active'] ?? 0, 'user-check', 'green', ['status' => 'active']],
        ['blocked', 'Blocked', $summary['blocked'] ?? 0, 'user-lock', 'red', ['status' => 'blocked']],
        ['internship', 'Internship', $summary['internship'] ?? 0, 'graduation-cap', 'amber', ['employee_group' => ['INTERNSHIP']]],
        ['locked', 'Profile locked', $summary['locked'] ?? 0, 'lock', 'gray', ['lock' => 'locked']],
    ];
@endphp
<div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
    @foreach($cards as [$key, $label, $count, $icon, $tone, $patch])
        <button type="button" data-card="{{ $key }}" data-patch='@json($patch)' onclick="applyCardFilter(this)"
                class="emp-card text-left bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex items-center gap-3 hover:shadow transition">
            <span class="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 {{ $tones[$tone] }}"><i class="fas fa-{{ $icon }}"></i></span>
            <span class="min-w-0">
                <span class="block text-2xl font-bold text-gray-800 leading-none">{{ number_format($count) }}</span>
                <span class="block text-[11px] text-gray-500 mt-1">{{ $label }}</span>
            </span>
        </button>
    @endforeach
</div>

<div class="bg-white rounded-xl p-6 shadow-sm">
    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b-2 border-gray-100">
        <h2 class="text-2xl font-bold text-gray-900">Employee Management</h2>
    </div>

    <!-- Table Section -->
    <div class="mt-6">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <div>
                <h3 class="text-lg font-semibold text-gray-900">Employee List</h3>
                <span id="employeeShowingText" class="text-xs text-gray-500"></span>
            </div>
            <div class="flex items-center gap-2.5">
                <button type="button" id="employeeResetFilters" onclick="resetFilters()" class="hidden inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-red-600 hover:text-red-700">
                    <i class="fas fa-filter-circle-xmark text-[11px]"></i> Reset filters
                </button>
                <button onclick="exportEmployees()" class="inline-flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-300 text-gray-700 text-sm font-semibold rounded-lg hover:bg-gray-50 transition-all duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 text-green-600">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
                    </svg>
                    Export Excel
                </button>
                @if($can('master.employee.create'))
                <button onclick="openCreateModal()" class="inline-flex items-center px-4 py-2 primary-gradient text-white text-sm font-semibold rounded-lg hover:opacity-90 transition-all duration-200">
                    Create Employee
                </button>
                @endif
            </div>
        </div>

        <!-- Pencarian: selalu terlihat. Memakai filter yang sama dengan "Full Name" di header tabel (ECI atau nama, per kata). -->
        <div class="mb-4 flex flex-wrap items-center gap-3" role="search">
            <div class="relative flex-1 min-w-[260px] max-w-2xl">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor" class="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                </svg>
                <input type="search" id="employeeSearchBox" autocomplete="off" spellcheck="false" maxlength="100"
                    placeholder="Search by name or employee ID (ECI)…" aria-label="Search employees"
                    class="w-full pl-10 pr-10 py-2.5 bg-white border border-gray-300 rounded-lg text-sm text-gray-800 placeholder-gray-400 shadow-sm hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-red-800 focus:border-transparent transition-all">
                <button type="button" id="employeeSearchClear" class="hidden absolute right-2.5 top-1/2 -translate-y-1/2 w-6 h-6 inline-flex items-center justify-center rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors" aria-label="Clear search" title="Clear search">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-3.5 h-3.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
                </button>
            </div>
            <span class="hidden md:inline text-[11px] text-gray-400">Press <kbd class="px-1.5 py-0.5 rounded border border-gray-200 bg-gray-50 text-gray-500 font-mono text-[10px]">/</kbd> to search · use the column filters for position, module, division and more</span>
        </div>

        <div id="employeeTableWrapper" class="overflow-x-auto border border-gray-200 rounded-lg" aria-busy="false">
            <table class="w-full" style="min-width:1600px;">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-700 uppercase tracking-wider border-b border-gray-200" style="min-width:100px;">ECI</th>
                        @include('master.employee.components.header-filter', ['key' => 'employee', 'label' => 'Full Name', 'type' => 'search', 'placeholder' => 'Search by ECI or name…', 'thStyle' => 'min-width:200px;'])
                        @include('master.employee.components.header-filter', ['key' => 'position', 'label' => 'Position', 'type' => 'checkboxes', 'options' => array_combine($positionOptions ?? [], $positionOptions ?? [])])
                        @include('master.employee.components.header-filter', ['key' => 'modules', 'label' => 'Module', 'type' => 'checkboxes', 'dynamic' => true])
                        @include('master.employee.components.header-filter', ['key' => 'employee_group', 'label' => 'Employee Group', 'type' => 'checkboxes', 'options' => array_combine(array_values(array_diff($employeeGroupOptions ?? [], ['EXTERNAL'])), array_values(array_diff($employeeGroupOptions ?? [], ['EXTERNAL']))), 'thStyle' => 'min-width:130px;'])
                        @include('master.employee.components.header-filter', ['key' => 'division', 'label' => 'Division', 'type' => 'checkboxes', 'options' => array_combine($divisionOptions ?? [], $divisionOptions ?? [])])
                        @include('master.employee.components.header-filter', ['key' => 'department', 'label' => 'Department', 'type' => 'checkboxes', 'options' => array_combine($departmentOptions ?? [], $departmentOptions ?? []), 'thStyle' => 'min-width:220px;'])
                        @include('master.employee.components.header-filter', ['key' => 'home_base', 'label' => 'Home Base', 'type' => 'checkboxes', 'options' => array_combine(\App\Enums\HomeBase::options(), \App\Enums\HomeBase::options())])
                        <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-700 uppercase tracking-wider border-b border-gray-200">Since Date</th>
                        @include('master.employee.components.header-filter', ['key' => 'status', 'label' => 'Status', 'type' => 'options', 'allLabel' => 'All Status', 'options' => ['active' => 'Active', 'blocked' => 'Inactive']])
                        @include('master.employee.components.header-filter', ['key' => 'lock', 'label' => 'Profile', 'type' => 'options', 'allLabel' => 'All profiles', 'options' => ['locked' => 'Locked by HR', 'unlocked' => 'Not locked']])
                        <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-700 uppercase tracking-wider border-b border-gray-200">Actions</th>
                    </tr>
                </thead>
                <tbody id="employeeTableBody" class="bg-white divide-y divide-gray-100">
                    <!-- Dynamic rows will be inserted here by JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div id="employeePagination" class="mt-4 px-1 min-h-[36px]"></div>
    </div>
</div>

<!-- Modal Create/Edit Employee dengan 3 Sections -->
<div id="employeeModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <!-- Modal Header -->
        <div class="flex justify-between items-center px-6 py-5 border-b border-gray-200">
            <h3 id="modalTitle" class="text-xl font-bold text-gray-900">Create Employee</h3>
            <button onclick="closeModal()" class="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 text-gray-600 hover:bg-red-800 hover:text-white transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Modal Body - 3 Columns Layout -->
        <div class="p-6">
            <form id="employeeForm">
                <input type="hidden" id="employeeId">
                <meta name="csrf-token" content="{{ csrf_token() }}">
                
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- SECTION 1: GENERAL DATA -->
                    <div class="space-y-4">
                        <h4 class="text-base font-bold text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">General Data</h4>
                        
                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Employee <span class="text-red-600">*</span></label>
                            <input type="text" id="eci" placeholder="e.g., ECI001" required class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Password <span class="text-red-600" id="passwordRequired">*</span></label>
                            <div class="relative">
                                <input type="password" id="password" placeholder="Enter password" class="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 pr-10">
                                <button type="button" onclick="togglePassword('password')" class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                    <svg id="eyeIconPassword" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                    </svg>
                                </button>
                            </div>
                            <small class="text-xs text-gray-500 mt-1" id="passwordHint">Leave blank to keep current password</small>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Confirm Password <span class="text-red-600" id="confirmPasswordRequired">*</span></label>
                            <div class="relative">
                                <input type="password" id="confirmPassword" placeholder="Re-enter password" class="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 pr-10">
                                <button type="button" onclick="togglePassword('confirmPassword')" class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                    <svg id="eyeIconConfirmPassword" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Title</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Title</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="title" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Title</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Mr.">Mr.</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Mrs.">Mrs.</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Ms.">Ms.</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Dr.">Dr.</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Prof.">Prof.</button>
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">First Name <span class="text-red-600">*</span></label>
                            <input type="text" id="firstName" required class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Last Name</label>
                            <input type="text" id="lastName" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Nick Name <span class="text-red-600">*</span></label>
                            <input type="text" id="nickName" required class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Gender</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Gender</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="gender" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Gender</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Male">Male</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Female">Female</button>
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Birth Date</label>
                            <input type="date" id="birthDate" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Birth Place</label>
                            <input type="text" id="birthPlace" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Since Date</label>
                            <input type="date" id="sinceDate" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>
                    </div>

                    <!-- SECTION 2: STANDARD ADDRESS -->
                    <div class="space-y-4">
                        <h4 class="text-base font-bold text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">Standard Address</h4>
                        
                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Street</label>
                            <input type="text" id="street" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">House Number</label>
                            <input type="text" id="houseNumber" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Postal Code</label>
                            <input type="text" id="postalCode" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        {{-- Alamat cascading (Country → Region → City → District → Village)
                             via tabel `wilayah` (API /api/regions/children). Nilai yang
                             disimpan tetap NAMA. Mirror halaman edit employee address. --}}
                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Country</label>
                            <select id="country" class="addr-select px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 bg-white">
                                <option value="Indonesia" selected>Indonesia</option>
                            </select>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Region/Province</label>
                            <select id="region" onchange="addrOnRegionChange()" data-searchable="true" data-search-placeholder="Search region..." class="addr-select px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 bg-white">
                                <option value="">-- Select Region --</option>
                            </select>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">City</label>
                            <select id="city" onchange="addrOnCityChange()" data-searchable="true" data-search-placeholder="Search city..." class="addr-select px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 bg-white">
                                <option value="">-- Select City --</option>
                            </select>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">District</label>
                            <select id="district" onchange="addrOnDistrictChange()" data-searchable="true" data-search-placeholder="Search district..." class="addr-select px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 bg-white">
                                <option value="">-- Select District --</option>
                            </select>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Rural / Urban Villages</label>
                            <select id="village" data-searchable="true" data-search-placeholder="Search village..." class="addr-select px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800 bg-white">
                                <option value="">-- Select Village --</option>
                            </select>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Language</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Language</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="language" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Language</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="English">English</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Indonesian">Indonesian</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Javanese">Javanese</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Sundanese">Sundanese</button>
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="Other">Other</button>
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Work Email <span class="text-red-600" id="emailWorkRequired">*</span></label>
                            <input type="email" id="emailWork" placeholder="e.g., name@company.com" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                            <small class="text-xs text-gray-500 mt-1">Used for account activation link</small>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Cell Phone</label>
                            <input type="text" id="cellPhone" placeholder="e.g., 08123456789" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>
                    </div>

                    <!-- SECTION 3: ORGANIZATIONAL DATA -->
                    <div class="space-y-4">
                        <h4 class="text-base font-bold text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">Organizational Data</h4>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Personnel Area</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Personnel Area</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="personnelArea" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Personnel Area</button>
                                    @foreach(($personnelAreaOptions ?? []) as $pa)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $pa }}">{{ $pa }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Position</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Position</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="position" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Position</button>
                                    @foreach(($positionOptions ?? []) as $pos)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $pos }}">{{ $pos }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Current Assignment</label>
                            <input type="text" id="currentAssignment" placeholder="e.g., Project X" class="px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-800">
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Employee Group</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Employee Group</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="employeeGroup" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Employee Group</button>
                                    @foreach(($employeeGroupOptions ?? []) as $eg)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $eg }}">{{ $eg }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Employee Sub-Group</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Employee Sub-Group</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="employeeSubgroup" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Employee Sub-Group</button>
                                    @foreach(($employeeSubgroupOptions ?? []) as $esg)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $esg }}">{{ $esg }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Division</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Division</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="division" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Division</button>
                                    @foreach(($divisionOptions ?? []) as $div)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $div }}">{{ $div }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col">
                            <label class="text-xs font-semibold text-gray-600 mb-1">Home Base</label>
                            <div class="custom-dd relative" data-fixed="true">
                                <button type="button" class="custom-dd-btn w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded text-sm hover:border-gray-400 transition-all text-left">
                                    <span class="custom-dd-label text-gray-500">Select Home Base</span>
                                    <svg class="custom-dd-arrow w-4 h-4 text-gray-400 transition-transform duration-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <input type="hidden" id="homeBase" value="">
                                <div class="custom-dd-panel hidden bg-white rounded-xl shadow-2xl border border-gray-100 py-1.5 overflow-y-auto" style="max-height:220px;">
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="">Select Home Base</button>
                                    @foreach(($homeBaseOptions ?? []) as $hb)
                                    <button type="button" class="custom-dd-item w-full text-left px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 transition-colors" data-value="{{ $hb }}">{{ $hb }}</button>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- Modal Footer -->
        <div class="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 bg-gray-50">
            <button onclick="closeModal()" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 text-sm font-semibold rounded-lg border border-gray-300 hover:bg-gray-50 transition-all duration-200">Cancel</button>
            <button onclick="saveEmployee()" class="inline-flex items-center px-4 py-2 primary-gradient text-white text-sm font-semibold rounded-lg hover:opacity-90 transition-all duration-200">
                Save
            </button>
        </div>
    </div>
</div>

<!-- Modal Change Password -->
<div id="changePasswordModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-md w-full shadow-2xl">
        <div class="flex justify-between items-center px-6 py-5 border-b border-gray-200">
            <div>
                <h3 class="text-lg font-bold text-gray-900">Change Password</h3>
                <p id="cpEmployeeName" class="text-sm text-gray-500 mt-0.5"></p>
            </div>
            <button onclick="closeChangePasswordModal()" class="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 text-gray-600 hover:bg-red-800 hover:text-white transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div class="p-6 space-y-4">
            <input type="hidden" id="cpEmployeeId">
            <div class="flex flex-col">
                <label class="text-xs font-semibold text-gray-600 mb-1">New Password <span class="text-red-600">*</span></label>
                <div class="relative">
                    <input type="password" id="cpNewPassword" placeholder="Enter new password" class="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10">
                    <button type="button" onclick="toggleCpField('cpNewPassword', 'cpEye1')" class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                        <svg id="cpEye1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                    </button>
                </div>
                <small class="text-xs text-gray-400 mt-1">Minimum 6 characters</small>
            </div>
            <div class="flex flex-col">
                <label class="text-xs font-semibold text-gray-600 mb-1">Confirm Password <span class="text-red-600">*</span></label>
                <div class="relative">
                    <input type="password" id="cpConfirmPassword" placeholder="Re-enter new password" class="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10">
                    <button type="button" onclick="toggleCpField('cpConfirmPassword', 'cpEye2')" class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                        <svg id="cpEye2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        <div class="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 bg-gray-50">
            <button onclick="closeChangePasswordModal()" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 text-sm font-semibold rounded-lg border border-gray-300 hover:bg-gray-50 transition-all duration-200">Cancel</button>
            <button onclick="submitChangePassword()" class="inline-flex items-center px-4 py-2 primary-gradient text-white text-sm font-semibold rounded-lg hover:opacity-90 transition-all duration-200">
                Change Password
            </button>
        </div>
    </div>
</div>

<!-- Modal Change ECI (konfirmasi kata sandi) -->
<div id="changeEciModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-md w-full shadow-2xl">
        <div class="flex justify-between items-center px-6 py-5 border-b border-gray-200">
            <div>
                <h3 class="text-lg font-bold text-gray-900">Change ECI</h3>
                <p id="ceEmployeeName" class="text-sm text-gray-500 mt-0.5"></p>
            </div>
            <button onclick="closeChangeEciModal()" class="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 text-gray-600 hover:bg-red-800 hover:text-white transition-all" aria-label="Close">&times;</button>
        </div>
        <div class="p-6 space-y-4">
            <input type="hidden" id="ceEmployeeId">
            <div class="flex flex-col">
                <label class="text-xs font-semibold text-gray-600 mb-1">Current ECI</label>
                <input type="text" id="ceCurrentEci" readonly class="w-full px-3 py-2.5 border border-gray-200 bg-gray-50 rounded-lg text-sm text-gray-600">
            </div>
            <div class="flex flex-col">
                <label class="text-xs font-semibold text-gray-600 mb-1">New ECI <span class="text-red-600">*</span></label>
                <input type="text" id="ceNewEci" maxlength="50" autocomplete="off" placeholder="e.g. K26001" class="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-red-800">
                <small class="text-xs text-gray-400 mt-1">Letters, numbers, dot, underscore, hyphen. Must be unique.</small>
            </div>
            <div class="flex flex-col">
                <label class="text-xs font-semibold text-gray-600 mb-1">Your password (to confirm) <span class="text-red-600">*</span></label>
                <input type="password" id="ceActorPassword" autocomplete="current-password" placeholder="Enter YOUR password" class="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-red-800">
            </div>
            <p class="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                The ECI is used to sign in. If this account's login username is the old ECI, it changes to the new one too (signing in with the email does not change).
                Payslips already issued keep the old ECI.
            </p>
        </div>
        <div class="flex justify-end gap-3 px-6 py-4 border-t border-gray-200">
            <button onclick="closeChangeEciModal()" class="px-4 py-2 text-sm font-semibold rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50">Cancel</button>
            <button id="ceSubmit" onclick="submitChangeEci()" class="px-4 py-2 text-sm font-semibold rounded-lg primary-gradient text-white hover:opacity-90">Change ECI</button>
        </div>
    </div>
</div>

<!-- Modal Change Role (multi-select via checkboxes) -->
<div id="changeRoleModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl w-full max-w-2xl shadow-2xl">
        <!-- Header -->
        <div class="flex justify-between items-center px-6 py-5 border-b border-gray-200">
            <div>
                <h3 class="text-lg font-bold text-gray-900">Assign Roles</h3>
                <p id="crEmployeeName" class="text-sm text-gray-500 mt-0.5"></p>
            </div>
            <button onclick="closeChangeRoleModal()" class="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 text-gray-600 hover:bg-red-800 hover:text-white transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <div class="px-6 pt-4 pb-2">
            <input type="hidden" id="crEmployeeId">

            <!-- Search + count -->
            <div class="flex items-center gap-3 mb-3">
                <div class="relative flex-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                    <input id="crRoleSearch" type="text" placeholder="Search role…"
                        oninput="filterCrRoles()"
                        class="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-800 focus:border-transparent">
                </div>
                <span id="crRoleCount" class="text-xs text-gray-400 whitespace-nowrap"></span>
            </div>

            <p class="text-xs font-semibold text-gray-600 mb-3">Select Roles <span class="text-red-600">*</span> <span class="font-normal text-gray-400">(pilih satu atau lebih)</span></p>
        </div>

        <!-- Role grid — 2 kolom -->
        <div class="px-6 pb-2 max-h-72 overflow-y-auto">
            <div id="crRoleCheckboxes" class="grid grid-cols-2 gap-2">
                <p class="col-span-2 text-sm text-gray-400">Loading roles...</p>
            </div>
            <p id="crRoleEmpty" class="hidden text-sm text-center text-gray-400 py-6">No matching roles found</p>
        </div>

        <!-- Footer -->
        <div class="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 bg-gray-50 rounded-b-xl">
            <button onclick="closeChangeRoleModal()" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 text-sm font-semibold rounded-lg border border-gray-300 hover:bg-gray-50 transition-all duration-200">Cancel</button>
            <button onclick="submitChangeRole()" class="inline-flex items-center px-4 py-2 primary-gradient text-white text-sm font-semibold rounded-lg hover:opacity-90 transition-all duration-200">
                Save Roles
            </button>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Delete -->
<div id="confirmDeleteModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl max-w-md w-full shadow-2xl">
        <div class="p-6">
            <div class="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-red-100 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 text-red-600">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
                </svg>
            </div>
            <h3 class="text-lg font-bold text-gray-900 text-center mb-2">Delete Employee</h3>
            <p class="text-sm text-gray-600 text-center mb-6">Are you sure you want to delete this employee?</p>
            <div class="flex gap-3">
                <button onclick="closeConfirmDelete()" class="flex-1 px-4 py-2.5 bg-white text-gray-700 text-sm font-semibold rounded-lg border border-gray-300 hover:bg-gray-50 transition-all">Cancel</button>
                <button onclick="confirmDelete()" class="flex-1 px-4 py-2.5 bg-red-600 text-white text-sm font-semibold rounded-lg hover:bg-red-700 transition-all">Delete</button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Chevron kustom untuk dropdown alamat cascading (Country → … → Village)
       di modal Create/Edit Employee. Mirror sections/address.blade.php. */
    .addr-select {
        -webkit-appearance: none; -moz-appearance: none; appearance: none;
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239ca3af' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 0.625rem center; background-size: 1rem;
        padding-right: 2rem;
    }

    /* Hover effect untuk baris tabel yang bisa diklik */
    .employee-row {
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .employee-row:hover {
        background-color: #fef2f2 !important;
    }

    /* Locked (sticky) columns: ECI + Full Name stay pinned while the table scrolls horizontally */
    #employeeTableWrapper table th:nth-child(1),
    #employeeTableWrapper table td:nth-child(1) {
        position: sticky;
        left: 0;
        z-index: 5;
        background: inherit;
        box-shadow: 2px 0 4px rgba(0,0,0,0.04);
        /* Samakan durasi dengan `.employee-row { transition: all .2s }` agar latar
           kolom sticky memudar SEIRING sisa baris saat hover (tanpa ini sel sticky
           berubah instan sementara sisa baris beranimasi → terasa ada delay). */
        transition: background-color 0.2s ease;
    }
    #employeeTableWrapper table th:nth-child(2),
    #employeeTableWrapper table td:nth-child(2) {
        position: sticky;
        left: 100px;
        z-index: 5;
        background: inherit;
        box-shadow: 2px 0 4px rgba(0,0,0,0.04);
        transition: background-color 0.2s ease;
    }
    #employeeTableWrapper thead th:nth-child(1),
    #employeeTableWrapper thead th:nth-child(2) {
        background: #f9fafb;
        z-index: 6;
    }
    #employeeTableWrapper tbody tr td:nth-child(1),
    #employeeTableWrapper tbody tr td:nth-child(2) {
        background: #fff;
    }
    .employee-row:hover td:nth-child(1),
    .employee-row:hover td:nth-child(2) {
        background-color: #fef2f2;
    }

    @if(session('user_preferences.theme','light') === 'dark')
    /* Kolom sticky (ECI + Full Name) memakai warna terang HARDCODED yang tak ikut
       ter-tema. Karena kolom ini di-freeze & mengambang di atas kolom lain saat
       scroll horizontal, latarnya wajib OPAQUE gelap — samakan dengan permukaan
       tema: header = bg-gray-50 (#0b1120), body = bg-white (#1f2937), hover =
       .employee-row:hover global (#374151). */
    #employeeTableWrapper thead th:nth-child(1),
    #employeeTableWrapper thead th:nth-child(2) { background: #0b1120 !important; }
    #employeeTableWrapper tbody tr td:nth-child(1),
    #employeeTableWrapper tbody tr td:nth-child(2) { background: #1f2937 !important; }
    #employeeTableWrapper .employee-row:hover td:nth-child(1),
    #employeeTableWrapper .employee-row:hover td:nth-child(2) { background-color: #374151 !important; }
    @endif

    /* Mencegah text selection saat double click */
    .employee-row {
        user-select: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
    }
</style>

<script src="/js/custom-dropdown.js?v={{ filemtime(public_path('js/custom-dropdown.js')) }}"></script>
<script>
    let employees = [];
    let currentEmployeeId = null;
    let deleteEmployeeId = null;
    let currentPage = 1;
    let paginationMeta = null;
    // Rows per page is chosen in the pagination footer and remembered for the session.
    const PER_PAGE_OPTIONS = [10, 25, 50, 100, 200];
    let perPage = (() => { const v = parseInt(sessionStorage.getItem('employeeManagementPerPage'), 10); return PER_PAGE_OPTIONS.includes(v) ? v : 50; })();

    /**
     * Tampilkan semua error validasi dari response API sebagai toast.
     * Jika ada data.errors (Laravel 422), tiap pesan ditampilkan.
     * Jika tidak, tampilkan data.message atau fallbackMsg.
     */
    function showApiErrors(data, fallbackMsg = 'Terjadi kesalahan, coba lagi') {
        if (data && data.errors && typeof data.errors === 'object') {
            const msgs = Object.values(data.errors).flat().filter(Boolean);
            if (msgs.length > 0) {
                const html = msgs.map(m => '• ' + m).join('<br>');
                showToast(html, 'error', 7000);
                return;
            }
        }
        showNotification(data?.message || fallbackMsg, 'error');
    }

    // Toggle password visibility
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const icon = document.getElementById('eyeIcon' + fieldId.charAt(0).toUpperCase() + fieldId.slice(1));
        
        if (field.type === 'password') {
            field.type = 'text';
            icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />`;
        } else {
            field.type = 'password';
            icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`;
        }
    }

    // Indikator memuat: baris kerangka (skeleton) saat tabel masih kosong, tabel diredupkan saat memuat ulang (pencarian/filter).
    let _empRequestSeq = 0;
    function setEmployeeLoading(on) {
        const tbody = document.getElementById('employeeTableBody');
        const wrap = document.getElementById('employeeTableWrapper');
        if (!tbody) return;
        wrap?.setAttribute('aria-busy', on ? 'true' : 'false');
        if (!on) { tbody.classList.remove('opacity-50'); return; }
        if (tbody.querySelector('tr.employee-row')) {
            tbody.classList.add('opacity-50');
        } else {
            tbody.innerHTML = Array.from({ length: 8 }, (_, i) => `
                <tr aria-hidden="true"><td colspan="12" class="px-4 py-3.5"><div class="h-4 rounded bg-gray-100 animate-pulse" style="width:${[92, 84, 96, 78, 88, 72, 94, 80][i]}%"></div></td></tr>`).join('');
        }
    }

    async function fetchEmployees(filters = {}, page = currentPage) {
        const mySeq = ++_empRequestSeq;
        setEmployeeLoading(true);
        try {
            const params = new URLSearchParams({ ...filters, page, per_page: perPage });
            const response = await fetch(`/api/employees?${params}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
                },
                credentials: 'same-origin'
            });

            const data = await response.json();
            if (mySeq !== _empRequestSeq) return;   // ada permintaan yang lebih baru (mis. masih mengetik): abaikan balasan lama

            if (data.success) {
                // Jika halaman saat ini melampaui jumlah halaman hasil (mis. setelah
                // filter/hapus membuat data menyusut), mundur ke halaman terakhir
                // yang valid lalu fetch ulang — cegah tampilan kosong.
                if (data.pagination && data.pagination.total > 0
                    && data.pagination.current_page > data.pagination.last_page) {
                    currentPage = data.pagination.last_page;
                    return fetchEmployees(filters, currentPage);
                }
                employees = data.data;
                paginationMeta = data.pagination || null;
                currentPage = paginationMeta ? paginationMeta.current_page : currentPage;
                renderTable(employees);
                renderPagination();
            } else {
                showNotification(data.message || 'Failed to fetch employees', 'error');
            }
        } catch (error) {
            if (mySeq === _empRequestSeq) {
                document.getElementById('employeeTableBody')?.querySelector('tr.employee-row') || renderTable([]);
                showNotification('An error occurred while fetching employees', 'error');
            }
        } finally {
            if (mySeq === _empRequestSeq) {
                setEmployeeLoading(false);
                // Gagal sebelum ada baris: jangan biarkan baris kerangka tertinggal selamanya
                if (document.querySelector('#employeeTableBody tr[aria-hidden="true"]')) renderTable([]);
            }
        }
    }

    function renderPagination() {
        const el = document.getElementById('employeePagination');
        const showingEl = document.getElementById('employeeShowingText');
        if (!el || !paginationMeta) return;

        const { total, current_page, last_page, from, to } = paginationMeta;

        if (showingEl) {
            showingEl.textContent = last_page <= 1
                ? `Showing ${total} employee${total !== 1 ? 's' : ''}`
                : `Showing ${from}–${to} of ${total} employees`;
        }
        if (total === 0) {
            el.innerHTML = '';
            return;
        }

        // Numbered footer (same look as KPI Evaluation / Recruitment): arrows, up to 5 pages around the current one,
        // "Showing x to y of z" and a "Rows per page" selector.
        const start = Math.max(1, Math.min(current_page - 2, last_page - 4));
        const end = Math.min(last_page, start + 4);
        const page = 'w-8 h-8 rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 font-semibold flex items-center justify-center text-xs shadow-sm transition-all';
        const arrow = 'w-8 h-8 rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 hover:text-gray-700 flex items-center justify-center text-xs shadow-sm transition-all';
        const arrowOff = 'w-8 h-8 rounded-lg border border-gray-100 bg-gray-50 text-gray-300 flex items-center justify-center text-xs cursor-not-allowed';
        const dots = '<span class="w-5 text-center text-gray-400 text-xs">...</span>';
        const link = (n) => `<button type="button" onclick="goToPage(${n})" class="${page}">${n}</button>`;

        let nav = current_page > 1
            ? `<button type="button" onclick="goToPage(${current_page - 1})" class="${arrow}" aria-label="Previous page"><i class="fas fa-chevron-left text-[10px]"></i></button>`
            : `<span class="${arrowOff}"><i class="fas fa-chevron-left text-[10px]"></i></span>`;
        if (start > 1) { nav += link(1) + (start > 2 ? dots : ''); }
        for (let n = start; n <= end; n++) {
            nav += n === current_page
                ? `<span class="w-8 h-8 rounded-lg text-white font-bold flex items-center justify-center text-xs shadow-sm" aria-current="page" style="background: var(--primary-surface, var(--primary-color)) !important;">${n}</span>`
                : link(n);
        }
        if (end < last_page) { nav += (end < last_page - 1 ? dots : '') + link(last_page); }
        nav += current_page < last_page
            ? `<button type="button" onclick="goToPage(${current_page + 1})" class="${arrow}" aria-label="Next page"><i class="fas fa-chevron-right text-[10px]"></i></button>`
            : `<span class="${arrowOff}"><i class="fas fa-chevron-right text-[10px]"></i></span>`;

        const options = PER_PAGE_OPTIONS.map(n => `<option value="${n}" ${n === perPage ? 'selected' : ''}>${n}</option>`).join('');
        el.innerHTML = `
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 w-full">
                <nav class="flex items-center gap-1.5 flex-wrap" aria-label="Pagination">
                    ${nav}
                    <span class="text-xs text-gray-500 ml-3 font-normal whitespace-nowrap">Showing ${from || 0} to ${to || 0} of ${total} results</span>
                </nav>
                <div class="flex items-center gap-2">
                    <label for="employeePerPage" class="text-xs text-gray-500 font-normal whitespace-nowrap">Rows per page:</label>
                    <div class="w-20"><select id="employeePerPage" onchange="changePerPage(this.value)">${options}</select></div>
                </div>
            </div>`;
    }

    function changePerPage(value) {
        const n = parseInt(value, 10);
        if (!PER_PAGE_OPTIONS.includes(n)) return;
        perPage = n;
        sessionStorage.setItem('employeeManagementPerPage', String(n));
        currentPage = 1;
        fetchEmployees(getCurrentFilters(), 1);
    }

    function getCurrentFilters() {
        const f = window.EMP_F;
        return {
            status: f.status,
            employee: f.employee,
            department: f.department.join(','),
            modules: f.modules.join(','),
            home_base: f.home_base.join(','),
            position: f.position.join(','),
            employee_group: f.employee_group.join(','),
            division: f.division.join(','),
            lock: f.lock,
        };
    }

    // Klik kartu ringkasan: ganti filter daftar dengan filter kartu itu (kartu "Total" = tanpa filter).
    function applyCardFilter(btn) {
        const patch = JSON.parse(btn.dataset.patch || '{}');
        ehfResetAll();
        Object.assign(window.EMP_F, patch);
        ehfSyncAll();
        currentPage = 1;
        toggleResetFilters();
        fetchEmployees(getCurrentFilters(), 1);
        markActiveCard(btn.dataset.card);
    }
    function markActiveCard(key) {
        document.querySelectorAll('.emp-card').forEach(c => {
            const on = c.dataset.card === key && key !== 'all';
            c.classList.toggle('border-red-300', on); c.classList.toggle('ring-2', on); c.classList.toggle('ring-red-200', on);
        });
    }

    function toggleResetFilters() {
        const any = Object.values(getCurrentFilters()).some(v => v !== '');
        document.getElementById('employeeResetFilters')?.classList.toggle('hidden', !any);
        syncEmployeeSearchBox();
    }

    // Kotak pencarian di atas tabel = filter "employee" (sama dengan pencarian di header Full Name).
    function syncEmployeeSearchBox() {
        const box = document.getElementById('employeeSearchBox');
        if (!box) return;
        const value = window.EMP_F ? window.EMP_F.employee : '';
        if (document.activeElement !== box && box.value !== value) box.value = value;
        document.getElementById('employeeSearchClear')?.classList.toggle('hidden', !box.value);
    }

    function initEmployeeSearch() {
        const box = document.getElementById('employeeSearchBox'), clear = document.getElementById('employeeSearchClear');
        if (!box) return;
        box.addEventListener('input', () => {
            clear?.classList.toggle('hidden', !box.value);
            ehfSearch('employee', box.value, 350);
        });
        box.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); ehfSearch('employee', box.value, 0); }
            if (e.key === 'Escape' && box.value) { e.stopPropagation(); box.value = ''; clear?.classList.add('hidden'); ehfSearch('employee', '', 0); }
        });
        clear?.addEventListener('click', () => { box.value = ''; clear.classList.add('hidden'); ehfSearch('employee', '', 0); box.focus(); });
        // Pintasan "/" memfokuskan pencarian (kecuali sedang mengetik di kolom lain).
        document.addEventListener('keydown', e => {
            if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
            const t = e.target, typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
            if (typing) return;
            e.preventDefault(); box.focus(); box.select();
        });
    }

    function goToPage(page) {
        currentPage = page;
        fetchEmployees(getCurrentFilters());
    }

    // Fungsi untuk navigasi ke halaman detail saat baris diklik
    function navigateToDetail(employeeId, event) {
        // Cek apakah yang diklik adalah tombol action
        if (event.target.closest('.action-buttons')) {
            return; // Jangan navigate jika klik tombol action
        }

        // Simpan filter + halaman aktif — dipulihkan lagi kalau user balik dari
        // halaman detail ini (lihat DOMContentLoaded handler di bawah).
        saveEmployeeFilterState();

        // Navigate ke halaman detail
        window.location.href = `/master/employee/${employeeId}`;
    }

    const EMP_FILTER_STORAGE_KEY = 'employeeManagementFilters';

    function saveEmployeeFilterState() {
        sessionStorage.setItem(EMP_FILTER_STORAGE_KEY, JSON.stringify({
            ...getCurrentFilters(),
            page: currentPage,
        }));
    }

    // Map untuk menyimpan data employee — hindari embedding data di HTML onclick attribute
    // yang rentan terhadap karakter spesial (", ', `, \) dalam nama karyawan
    const _empRowData = new Map();

    function renderTable(data = employees) {
        const tbody = document.getElementById('employeeTableBody');

        if (data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="12" class="px-4 py-16 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-16 h-16 mx-auto mb-4 text-gray-300">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                        </svg>
                        ${Object.values(getCurrentFilters()).some(v => v !== '')
                            ? `<p class="text-base font-medium text-gray-900 mb-2">No employees match your search</p>
                               <small class="text-sm text-gray-500">Check the spelling, try fewer words, or <a href="#" onclick="resetFilters(); return false;" class="underline font-semibold">reset the filters</a>.</small>`
                            : `<p class="text-base font-medium text-gray-900 mb-2">No employees found</p>
                               <small class="text-sm text-gray-500">Click "Create Employee" to add a new employee</small>`}
                    </td>
                </tr>
            `;
            _empRowData.clear();
            return;
        }

        // Simpan data di Map (bukan di HTML attribute) agar aman dari karakter spesial
        // Gunakan Number() sebagai key agar konsisten — PDO di production kadang
        // mengembalikan integer column sebagai string sehingga Map.get(123) tidak
        // menemukan key "123". Normalisasi ke Number menghindari mismatch ini.
        _empRowData.clear();
        data.forEach(emp => {
            const fullName = [emp.first_name, emp.last_name].filter(n => n).join(' ') || '-';
            _empRowData.set(Number(emp.id), {
                name    : fullName,
                eci     : emp.eci || '',
                roleIds : emp.roles ? emp.roles.map(r => Number(r.id)) : [],
            });
        });

        tbody.innerHTML = data.map(emp => {
            const statusInfo = getStatusInfo(emp);
            // Number() cast wajib agar konsisten dengan _empRowData.set di atas.
            // Tanpa cast, key string ("123") dari PDO production tidak ketemu key
            // number (123) di Map → fullName kembali '-' di deploy walau jalan di local.
            const fullName   = _empRowData.get(Number(emp.id))?.name ?? '-';

            return `
            <tr class="employee-row" onclick="navigateToDetail(${emp.id}, event)">
                <td class="px-4 py-3.5 text-sm" style="min-width:100px;"><strong class="font-semibold text-gray-900">${emp.eci || '-'}</strong></td>
                <td class="px-4 py-3.5 text-sm text-gray-600" style="min-width:200px;">${fullName}</td>
                <td class="px-4 py-3.5 text-sm text-gray-600">${emp.position || '-'}</td>
                <td class="px-4 py-3.5 text-sm text-gray-600">${(emp.modules && emp.modules.length) ? emp.modules.join(', ') : '-'}</td>
                <td class="px-4 py-3.5 text-sm">${renderEmployeeGroup(emp.employee_group)}</td>
                <td class="px-4 py-3.5 text-sm text-gray-600">${emp.division || '-'}</td>
                {{-- Kolom Department membaca eb.department. Sebelumnya keliru
                     merender employee_subgroup sehingga selalu tampil "-". --}}
                <td class="px-4 py-3.5 text-sm text-gray-600">${emp.department || '-'}</td>
                <td class="px-4 py-3.5 text-sm text-gray-600">${emp.home_base || '-'}</td>
                <td class="px-4 py-3.5 text-sm text-gray-600">${emp.since_date || '-'}</td>
                <td class="px-4 py-3.5 text-sm">
                    <span class="inline-block px-3 py-1 text-xs font-semibold rounded-full ${statusInfo.class}">
                        ${statusInfo.label}
                    </span>
                </td>
                <td class="px-4 py-3.5 text-sm">
                    ${emp.profile_locked_at
                        ? '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 text-[11px] font-semibold rounded-full bg-gray-200 text-gray-700" title="Verified and locked by HR"><i class="fas fa-lock text-[9px]"></i> Locked</span>'
                        : '<span class="text-gray-400">—</span>'}
                </td>
                <td class="px-4 py-3.5 text-sm">
                    ${canEmployeeAction ? `<div class="action-buttons" onclick="event.stopPropagation()">
                        <button onclick="openEmpMenu(event, ${emp.id})" class="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 transition-all">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor" class="w-4 h-4">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/>
                            </svg>
                        </button>
                    </div>` : ''}
                </td>
            </tr>
        `;
        }).join('');
    }

    /**
     * Employee Group (INTERNAL / EXTERNAL / INTERNSHIP) — penanda jenis employee
     * yang menggantikan pemakaian Home Base "Others" sebagai indikator lama.
     */
    function renderEmployeeGroup(group) {
        const value = (group || '').trim();
        if (!value) return '<span class="text-gray-600">-</span>';

        const palette = {
            'INTERNAL'  : 'bg-blue-100 text-blue-700',
            'EXTERNAL'  : 'bg-amber-100 text-amber-700',
            'INTERNSHIP': 'bg-purple-100 text-purple-700',
        };
        const cls = palette[value.toUpperCase()] || 'bg-gray-100 text-gray-700';
        const safe = value.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
        return `<span class="inline-block px-2.5 py-0.5 text-[11px] font-semibold rounded-full ${cls}">${safe}</span>`;
    }

    function getStatusInfo(emp) {
        const status = emp.status?.toLowerCase() || 'active';
        const statusMap = {
            'active': { label: 'Active', class: 'bg-green-100 text-green-800' },
            'blocked': { label: 'Blocked', class: 'bg-yellow-100 text-yellow-800' },
            'deleted': { label: 'Flagged for Deletion', class: 'bg-red-100 text-red-800' }
        };
        return statusMap[status] || statusMap['active'];
    }

    /* ─────────────────────────────────────────────────────────────────────
       CASCADING DROPDOWN WILAYAH (Create/Edit Employee modal)
       Country → Region → City → District → Rural/Urban Village.
       Sumber: /api/regions/children (tabel `wilayah`). Nilai yang DISIMPAN
       tetap NAMA (kolom region/city/district/rural_urban_village). Kode wilayah
       dibawa di data-code tiap <option> untuk menautkan ke level di bawahnya.
       Port dari resources/views/master/employee/sections/address.blade.php.
       ───────────────────────────────────────────────────────────────────── */
    const addrRegionSel   = () => document.getElementById('region');
    const addrCitySel     = () => document.getElementById('city');
    const addrDistrictSel = () => document.getElementById('district');
    const addrVillageSel  = () => document.getElementById('village');

    function addrSelectedCode(sel) {
        const o = sel && sel.options[sel.selectedIndex];
        return o ? (o.dataset.code || '') : '';
    }

    async function addrFetchWilayah(parentCode) {
        try {
            const res = await fetch(`/api/regions/children?parent=${encodeURIComponent(parentCode)}`, {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            });
            const data = await res.json();
            return data.success ? data.data : [];
        } catch (e) {
            console.error('Error loading wilayah:', e);
            return [];
        }
    }

    // Isi <select> dengan daftar wilayah. selectedName = nama yang ingin dipilih
    // ulang (saat edit); bila tak ada di daftar resmi (data lama free-text), tetap
    // ditambahkan sebagai opsi agar tidak hilang. Dispatch 'change' agar
    // select-enhance menyegarkan label tampilannya.
    function addrFillWilayah(sel, items, placeholder, selectedName = '') {
        sel.innerHTML = `<option value="">${placeholder}</option>`;
        let matched = false;
        items.forEach(it => {
            const opt = document.createElement('option');
            opt.value = it.name;
            opt.dataset.code = it.code;
            opt.textContent = it.name;
            if (selectedName && selectedName === it.name) { opt.selected = true; matched = true; }
            sel.appendChild(opt);
        });
        if (selectedName && !matched) {
            const opt = document.createElement('option');
            opt.value = selectedName;
            opt.textContent = selectedName;
            opt.selected = true;
            sel.appendChild(opt);
        }
        sel.dispatchEvent(new Event('change', { bubbles: false }));
    }

    function addrResetWilayah(sel, placeholder) {
        sel.innerHTML = `<option value="">${placeholder}</option>`;
        sel.dispatchEvent(new Event('change', { bubbles: false }));
    }

    let addrRegionsReady = null;
    function addrLoadRegions(selectedName = '') {
        addrRegionsReady = addrFetchWilayah('').then(items => {
            addrFillWilayah(addrRegionSel(), items, '-- Select Region --', selectedName);
        });
        return addrRegionsReady;
    }

    async function addrOnRegionChange() {
        addrResetWilayah(addrCitySel(), '-- Select City --');
        addrResetWilayah(addrDistrictSel(), '-- Select District --');
        addrResetWilayah(addrVillageSel(), '-- Select Village --');
        const code = addrSelectedCode(addrRegionSel());
        if (code) addrFillWilayah(addrCitySel(), await addrFetchWilayah(code), '-- Select City --');
    }
    async function addrOnCityChange() {
        addrResetWilayah(addrDistrictSel(), '-- Select District --');
        addrResetWilayah(addrVillageSel(), '-- Select Village --');
        const code = addrSelectedCode(addrCitySel());
        if (code) addrFillWilayah(addrDistrictSel(), await addrFetchWilayah(code), '-- Select District --');
    }
    async function addrOnDistrictChange() {
        addrResetWilayah(addrVillageSel(), '-- Select Village --');
        const code = addrSelectedCode(addrDistrictSel());
        if (code) addrFillWilayah(addrVillageSel(), await addrFetchWilayah(code), '-- Select Village --');
    }

    // Rekonstruksi seluruh rantai dropdown dari nilai tersimpan (saat edit).
    async function addrHydrateLocation(regionName, cityName, districtName, villageName) {
        await addrLoadRegions(regionName || '');
        const rCode = addrSelectedCode(addrRegionSel());
        addrFillWilayah(addrCitySel(), rCode ? await addrFetchWilayah(rCode) : [], '-- Select City --', cityName || '');
        const cCode = addrSelectedCode(addrCitySel());
        addrFillWilayah(addrDistrictSel(), cCode ? await addrFetchWilayah(cCode) : [], '-- Select District --', districtName || '');
        const dCode = addrSelectedCode(addrDistrictSel());
        addrFillWilayah(addrVillageSel(), dCode ? await addrFetchWilayah(dCode) : [], '-- Select Village --', villageName || '');
    }

    // Kosongkan seluruh rantai dropdown ke kondisi awal (mode Create).
    function addrResetLocation() {
        addrLoadRegions();
        addrResetWilayah(addrCitySel(), '-- Select City --');
        addrResetWilayah(addrDistrictSel(), '-- Select District --');
        addrResetWilayah(addrVillageSel(), '-- Select Village --');
    }

    function openCreateModal() {
        currentEmployeeId = null;
        document.getElementById('modalTitle').textContent = 'Create Employee';
        document.getElementById('employeeForm').reset();
        document.getElementById('employeeId').value = '';

        // Reset modal custom dropdowns
        if (typeof setCustomDropdownValue === 'function') {
            setCustomDropdownValue('title', '');
            setCustomDropdownValue('gender', '');
            setCustomDropdownValue('language', '');
            setCustomDropdownValue('homeBase', '');
            setCustomDropdownValue('personnelArea', '');
            setCustomDropdownValue('position', '');
            setCustomDropdownValue('employeeGroup', '');
            setCustomDropdownValue('employeeSubgroup', '');
            setCustomDropdownValue('division', '');
        }

        // Set default value for Country + reset rantai dropdown wilayah (kosong).
        document.getElementById('country').value = 'Indonesia';
        addrResetLocation();

        // Set password as required for create
        document.getElementById('password').required = true;
        document.getElementById('confirmPassword').required = true;
        document.getElementById('passwordRequired').classList.remove('hidden');
        document.getElementById('confirmPasswordRequired').classList.remove('hidden');
        document.getElementById('passwordHint').classList.add('hidden');

        // Set email_work as required for create
        document.getElementById('emailWork').required = true;
        document.getElementById('emailWorkRequired').classList.remove('hidden');
        
        document.getElementById('employeeModal').classList.remove('hidden');
        document.getElementById('employeeModal').classList.add('flex');
    }

    function closeModal() {
        document.getElementById('employeeModal').classList.add('hidden');
        document.getElementById('employeeModal').classList.remove('flex');
        currentEmployeeId = null;
    }

    async function editEmployee(id) {
        try {
            const response = await fetch(`/api/employees/${id}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                credentials: 'same-origin'
            });

            const data = await response.json();
            
            if (data.success) {
                const emp = data.data;
                currentEmployeeId = id;
                
                // SECTION 1: GENERAL DATA
                document.getElementById('eci').value = emp.eci || '';
                document.getElementById('firstName').value = emp.first_name || '';
                document.getElementById('lastName').value = emp.last_name || '';
                document.getElementById('nickName').value = emp.nick_name || '';
                if (typeof setCustomDropdownValue === 'function') {
                    setCustomDropdownValue('title', emp.title || '');
                    setCustomDropdownValue('gender', emp.gender || '');
                } else {
                    document.getElementById('title').value = emp.title || '';
                    document.getElementById('gender').value = emp.gender || '';
                }
                document.getElementById('birthDate').value = emp.birth_date || '';
                document.getElementById('birthPlace').value = emp.birth_place || '';
                document.getElementById('sinceDate').value = emp.since_date || '';
                
                // Clear password fields
                document.getElementById('password').value = '';
                document.getElementById('confirmPassword').value = '';
                
                // Set password as optional for edit
                document.getElementById('password').required = false;
                document.getElementById('confirmPassword').required = false;
                document.getElementById('passwordRequired').classList.add('hidden');
                document.getElementById('confirmPasswordRequired').classList.add('hidden');
                document.getElementById('passwordHint').classList.remove('hidden');

                // Set email_work as optional for edit
                document.getElementById('emailWork').required = false;
                document.getElementById('emailWorkRequired').classList.add('hidden');
                
                // SECTION 2: STANDARD ADDRESS
                document.getElementById('street').value = emp.street || '';
                document.getElementById('houseNumber').value = emp.house_number || '';
                document.getElementById('postalCode').value = emp.postal_code || '';
                document.getElementById('country').value = emp.country || 'Indonesia';
                // Rekonstruksi dropdown cascading Region → City → District → Village.
                await addrHydrateLocation(emp.region, emp.city, emp.district, emp.rural_urban_village);
                if (typeof setCustomDropdownValue === 'function') {
                    setCustomDropdownValue('language', emp.language || '');
                } else {
                    document.getElementById('language').value = emp.language || '';
                }
                document.getElementById('emailWork').value = emp.email_work || '';
                document.getElementById('cellPhone').value = emp.cell_phone || '';
                
                // SECTION 3: ORGANIZATIONAL DATA
                document.getElementById('currentAssignment').value = emp.current_assignment || '';
                if (typeof setCustomDropdownValue === 'function') {
                    setCustomDropdownValue('personnelArea', emp.personnel_area || '');
                    setCustomDropdownValue('position', emp.position || '');
                    setCustomDropdownValue('employeeGroup', emp.employee_group || '');
                    setCustomDropdownValue('employeeSubgroup', emp.employee_subgroup || '');
                    setCustomDropdownValue('division', emp.division || '');
                    setCustomDropdownValue('homeBase', emp.home_base || '');
                } else {
                    document.getElementById('personnelArea').value = emp.personnel_area || '';
                    document.getElementById('position').value = emp.position || '';
                    document.getElementById('employeeGroup').value = emp.employee_group || '';
                    document.getElementById('employeeSubgroup').value = emp.employee_subgroup || '';
                    document.getElementById('division').value = emp.division || '';
                    document.getElementById('homeBase').value = emp.home_base || '';
                }

                document.getElementById('modalTitle').textContent = 'Edit Employee';
                document.getElementById('employeeModal').classList.remove('hidden');
                document.getElementById('employeeModal').classList.add('flex');
            } else {
                showNotification('Failed to load employee data', 'error');
            }
        } catch (error) {
            showNotification('An error occurred while loading employee data', 'error');
        }
    }

    async function saveEmployee() {
        const form = document.getElementById('employeeForm');
        
        // Validate password match
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        if (password || confirmPassword) {
            if (password !== confirmPassword) {
                showNotification('Passwords do not match!', 'error');
                return;
            }
            if (password.length < 6) {
                showNotification('Password must be at least 6 characters long!', 'error');
                return;
            }
        }
        
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const employeeData = {
            // SECTION 1: GENERAL DATA
            eci: document.getElementById('eci').value,
            title: document.getElementById('title').value,
            first_name: document.getElementById('firstName').value,
            last_name: document.getElementById('lastName').value,
            nick_name: document.getElementById('nickName').value,
            gender: document.getElementById('gender').value,
            birth_date: document.getElementById('birthDate').value,
            birth_place: document.getElementById('birthPlace').value,
            since_date: document.getElementById('sinceDate').value,
            
            // SECTION 2: STANDARD ADDRESS
            street: document.getElementById('street').value,
            house_number: document.getElementById('houseNumber').value,
            postal_code: document.getElementById('postalCode').value,
            country: document.getElementById('country').value,
            region: document.getElementById('region').value,
            city: document.getElementById('city').value,
            district: document.getElementById('district').value,
            rural_urban_village: document.getElementById('village').value,
            language: document.getElementById('language').value,
            email_work: document.getElementById('emailWork').value,
            cell_phone: document.getElementById('cellPhone').value,
            
            // SECTION 3: ORGANIZATIONAL DATA
            personnel_area: document.getElementById('personnelArea').value,
            position: document.getElementById('position').value,
            current_assignment: document.getElementById('currentAssignment').value,
            employee_group: document.getElementById('employeeGroup').value,
            employee_subgroup: document.getElementById('employeeSubgroup').value,
            division: document.getElementById('division').value,
            home_base: document.getElementById('homeBase').value,
        };

        // Add password only if it's provided
        if (password) {
            employeeData.password = password;
            employeeData.password_confirmation = confirmPassword;
        }

        if (!currentEmployeeId) {
            employeeData.role_id = 3;
        }

        try {
            let url = '/api/employees';
            let method = 'POST';
            
            if (currentEmployeeId) {
                url = `/api/employees/${currentEmployeeId}`;
                method = 'PUT';
            }

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                },
                credentials: 'same-origin',
                body: JSON.stringify(employeeData)
            });

            const data = await response.json();
            
            if (data.success) {
                const toExternal = (employeeData.employee_group || '') === 'EXTERNAL';
                showNotification(currentEmployeeId ? 'Employee updated successfully!' : 'Employee created successfully!', 'success');
                closeModal();
                if (toExternal) {
                    // Konsultan eksternal tidak tampil di daftar ini — lanjutkan ke halaman External → Consultants.
                    setTimeout(() => { window.location.href = '{{ route("general.external.consultants.index") }}'; }, 900);
                } else {
                    fetchEmployees();
                }
            } else {
                showApiErrors(data, 'Failed to save employee record');
            }
        } catch (error) {
            showNotification('An error occurred while saving employee', 'error');
        }
    }

    function deleteEmployee(id) {
        deleteEmployeeId = id;
        document.getElementById('confirmDeleteModal').classList.remove('hidden');
        document.getElementById('confirmDeleteModal').classList.add('flex');
    }

    function closeConfirmDelete() {
        document.getElementById('confirmDeleteModal').classList.add('hidden');
        document.getElementById('confirmDeleteModal').classList.remove('flex');
        deleteEmployeeId = null;
    }

    async function confirmDelete() {
        if (!deleteEmployeeId) return;

        try {
            const response = await fetch(`/api/employees/${deleteEmployeeId}/delete`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                },
                credentials: 'same-origin'
            });

            const data = await response.json();
            
            if (data.success) {
                showNotification('Employee deleted successfully!', 'success');
                closeConfirmDelete();
                fetchEmployees();
            } else {
                showNotification('Failed to delete employee: ' + (data.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            showNotification('An error occurred while deleting employee', 'error');
        }
    }

    function applyFilters() {
        currentPage = 1;
        toggleResetFilters();
        fetchEmployees(getCurrentFilters());
    }

    // Export Excel — filter yang dikirim persis sama dengan getCurrentFilters() yang
    // dipakai fetchEmployees(), jadi hasil export selalu konsisten dengan filter aktif.
    function exportEmployees() {
        const params = new URLSearchParams();
        Object.entries(getCurrentFilters()).forEach(([key, value]) => {
            if (value) params.set(key, value);
        });
        const qs = params.toString();
        window.location.href = '{{ route("master.employee.export") }}' + (qs ? '?' + qs : '');
    }

    function resetFilters() {
        markActiveCard('all');
        ehfResetAll();
        currentPage = 1;
        toggleResetFilters();
        fetchEmployees({});
    }



    // ── Change Password ────────────────────────────────────────────────────────
    function toggleCpField(fieldId, iconId) {
        const field = document.getElementById(fieldId);
        const isHidden = field.type === 'password';
        field.type = isHidden ? 'text' : 'password';
        const icon = document.getElementById(iconId);
        icon.innerHTML = isHidden
            ? `<path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />`
            : `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`;
    }

    function openChangePasswordModal(employeeId, employeeName) {
        document.getElementById('cpEmployeeId').value = employeeId;
        document.getElementById('cpEmployeeName').textContent = employeeName;
        document.getElementById('cpNewPassword').value = '';
        document.getElementById('cpConfirmPassword').value = '';
        document.getElementById('changePasswordModal').classList.remove('hidden');
        document.getElementById('changePasswordModal').classList.add('flex');
        document.getElementById('cpNewPassword').focus();
    }

    function closeChangePasswordModal() {
        document.getElementById('changePasswordModal').classList.add('hidden');
        document.getElementById('changePasswordModal').classList.remove('flex');
    }

    async function submitChangePassword() {
        const employeeId = document.getElementById('cpEmployeeId').value;
        const password = document.getElementById('cpNewPassword').value.trim();
        const confirmation = document.getElementById('cpConfirmPassword').value.trim();

        if (!password) {
            showNotification('New password is required', 'error');
            return;
        }
        if (password.length < 6) {
            showNotification('Password must be at least 6 characters', 'error');
            return;
        }
        if (password !== confirmation) {
            showNotification('Password confirmation does not match', 'error');
            return;
        }

        try {
            const response = await fetch(`/api/employees/${employeeId}/change-password`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                },
                credentials: 'same-origin',
                body: JSON.stringify({ password, password_confirmation: confirmation }),
            });

            const data = await response.json();

            if (data.success) {
                showNotification('Password updated successfully!', 'success');
                closeChangePasswordModal();
            } else {
                showApiErrors(data, 'Failed to update password');
            }
        } catch (error) {
            showNotification('An error occurred, please try again', 'error');
        }
    }

    // ── Change ECI (konfirmasi kata sandi akun yang mengganti) ─────────────────
    function openChangeEciModal(employeeId, employeeName, currentEci) {
        document.getElementById('ceEmployeeId').value = employeeId;
        document.getElementById('ceEmployeeName').textContent = employeeName || '';
        document.getElementById('ceCurrentEci').value = currentEci || '';
        document.getElementById('ceNewEci').value = '';
        document.getElementById('ceActorPassword').value = '';
        const m = document.getElementById('changeEciModal');
        m.classList.remove('hidden'); m.classList.add('flex');
        document.getElementById('ceNewEci').focus();
    }
    function closeChangeEciModal() {
        const m = document.getElementById('changeEciModal');
        m.classList.add('hidden'); m.classList.remove('flex');
        document.getElementById('ceActorPassword').value = '';
    }
    async function submitChangeEci() {
        const employeeId = document.getElementById('ceEmployeeId').value;
        const eci = document.getElementById('ceNewEci').value.trim();
        const password = document.getElementById('ceActorPassword').value;
        if (!eci) { showNotification('New ECI is required', 'error'); return; }
        if (!/^[A-Za-z0-9][A-Za-z0-9._-]{1,49}$/.test(eci)) { showNotification('ECI may only contain letters, numbers, dot, underscore and hyphen (2-50 characters)', 'error'); return; }
        if (!password) { showNotification('Enter your password to confirm', 'error'); return; }
        const btn = document.getElementById('ceSubmit');
        btn.disabled = true;
        try {
            const response = await fetch(`/api/employees/${employeeId}/change-eci`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                },
                credentials: 'same-origin',
                body: JSON.stringify({ eci, password }),
            });
            let data;
            try { data = await response.json(); } catch (_) { showNotification(`Server error (HTTP ${response.status}) — please refresh and try again`, 'error'); return; }
            if (data.success) {
                showNotification('ECI changed successfully', 'success');
                closeChangeEciModal();
                fetchEmployees();
            } else {
                showApiErrors(data, 'Failed to change ECI');
            }
        } catch (error) {
            showNotification('Network error — please check your connection and try again', 'error');
        } finally {
            btn.disabled = false;
        }
    }

    // ── Change Role (multi) ────────────────────────────────────────────────────
    let allRoles = [];

    async function loadRoles() {
        if (allRoles.length > 0) return;
        try {
            const response = await fetch('/api/employees/roles', {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin',
            });
            const data = await response.json();
            if (data.success) {
                allRoles = data.data;
            } else {
                showNotification(data.message || 'Failed to load roles', 'error');
            }
        } catch (e) {
            showNotification('Failed to load roles — please refresh the page', 'error');
        }
    }

    // Render satu item checkbox role
    function crRoleItemHtml(r, checked) {
        return `
            <label class="cr-role-item flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer transition-all
                ${checked ? 'border-red-300 bg-red-50' : 'border-gray-200 hover:bg-purple-50 hover:border-purple-300'}"
                data-name="${r.name.toLowerCase()}">
                <input type="checkbox" value="${r.id}"
                    class="cr-role-checkbox mt-0.5 w-4 h-4 shrink-0 text-red-600 border-gray-300 rounded focus:ring-red-500 cursor-pointer"
                    ${checked ? 'checked' : ''}
                    onchange="onCrRoleChange(this)">
                <span class="text-xs font-semibold text-gray-800 leading-tight">${r.name}</span>
            </label>`;
    }

    function onCrRoleChange(cb) {
        const label = cb.closest('label');
        if (cb.checked) {
            label.classList.add('border-red-300', 'bg-red-50');
            label.classList.remove('border-gray-200', 'hover:bg-purple-50', 'hover:border-purple-300');
        } else {
            label.classList.remove('border-red-300', 'bg-red-50');
            label.classList.add('border-gray-200', 'hover:bg-purple-50', 'hover:border-purple-300');
        }
        updateCrCount();
    }

    function updateCrCount() {
        const total   = document.querySelectorAll('.cr-role-checkbox').length;
        const checked = document.querySelectorAll('.cr-role-checkbox:checked').length;
        const el = document.getElementById('crRoleCount');
        if (el) el.textContent = checked ? `${checked} selected of ${total}` : `${total} roles`;
    }

    function filterCrRoles() {
        const q = (document.getElementById('crRoleSearch')?.value || '').toLowerCase().trim();
        const items = document.querySelectorAll('.cr-role-item');
        let visible = 0;
        items.forEach(item => {
            const match = !q || item.dataset.name.includes(q);
            item.style.display = match ? '' : 'none';
            if (match) visible++;
        });
        const empty = document.getElementById('crRoleEmpty');
        if (empty) empty.classList.toggle('hidden', visible > 0);
    }

    async function openChangeRoleModal(employeeId, employeeName, currentRoleIds) {
        await loadRoles();

        document.getElementById('crEmployeeId').value = employeeId;
        document.getElementById('crEmployeeName').textContent = employeeName;

        // Reset search
        const searchEl = document.getElementById('crRoleSearch');
        if (searchEl) searchEl.value = '';

        const container = document.getElementById('crRoleCheckboxes');
        const empty     = document.getElementById('crRoleEmpty');
        if (empty) empty.classList.add('hidden');

        if (!allRoles.length) {
            container.innerHTML = '<p class="col-span-2 text-sm text-gray-400">No roles available</p>';
        } else {
            // Normalize to Number to guard against PDO returning strings in some MySQL configs
            const currentRoleNums = currentRoleIds.map(Number);
            container.innerHTML = allRoles.map(r => crRoleItemHtml(r, currentRoleNums.includes(Number(r.id)))).join('');
            updateCrCount();
        }

        document.getElementById('changeRoleModal').classList.remove('hidden');
        document.getElementById('changeRoleModal').classList.add('flex');
    }

    function closeChangeRoleModal() {
        document.getElementById('changeRoleModal').classList.add('hidden');
        document.getElementById('changeRoleModal').classList.remove('flex');
    }

    async function submitChangeRole() {
        const employeeId = document.getElementById('crEmployeeId').value;
        const checked = [...document.querySelectorAll('.cr-role-checkbox:checked')].map(cb => parseInt(cb.value));

        if (!checked.length) {
            showNotification('Please select at least one role', 'error');
            return;
        }

        try {
            const response = await fetch(`/api/employees/${employeeId}/change-role`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                },
                credentials: 'same-origin',
                body: JSON.stringify({ role_ids: checked }),
            });

            let data;
            try {
                data = await response.json();
            } catch (_) {
                showNotification(`Server error (HTTP ${response.status}) — please refresh and try again`, 'error');
                return;
            }

            if (data.success) {
                const names = data.data.roles.map(r => r.name).join(', ');
                showNotification(`Role updated successfully: ${names}`, 'success');
                closeChangeRoleModal();
                fetchEmployees();
            } else {
                showApiErrors(data, 'Failed to update role');
            }
        } catch (error) {
            showNotification('Network error — please check your connection and try again', 'error');
        }
    }

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (!document.getElementById('employeeModal').classList.contains('hidden')) {
                closeModal();
            }
            if (!document.getElementById('confirmDeleteModal').classList.contains('hidden')) {
                closeConfirmDelete();
            }
            if (!document.getElementById('changePasswordModal').classList.contains('hidden')) {
                closeChangePasswordModal();
            }
            if (!document.getElementById('changeRoleModal').classList.contains('hidden')) {
                closeChangeRoleModal();
            }
        }
    });

    // Initialize on page load.
    // Filter dipulihkan HANYA kalau user balik dari halaman detail employee (dicek
    // lewat document.referrer) — supaya klik salah satu baris → lihat detail → balik
    // tetap mempertahankan filter, tapi pindah ke menu lain lalu balik lagi ke
    // Employee Management dari sidebar/link lain akan selalu mulai fresh (tanpa filter).
    document.addEventListener('DOMContentLoaded', async function() {
        const cameFromDetail = /\/master\/employee\/\d+(?:[/?].*)?$/.test(document.referrer);
        let restored = null;
        if (cameFromDetail) {
            const saved = sessionStorage.getItem(EMP_FILTER_STORAGE_KEY);
            if (saved) {
                try { restored = JSON.parse(saved); } catch (e) { restored = null; }
            }
        } else {
            sessionStorage.removeItem(EMP_FILTER_STORAGE_KEY);
        }

        // Module options come from the API; load them first so a restored selection can be ticked.
        if (restored) {
            const list = v => (v || '').split(',').filter(Boolean);
            Object.assign(window.EMP_F, {
                status: restored.status || '', employee: restored.employee || '', department: list(restored.department),
                modules: list(restored.modules), home_base: list(restored.home_base), position: list(restored.position),
                employee_group: list(restored.employee_group), division: list(restored.division), lock: restored.lock || '',
            });
            if (restored.page) currentPage = restored.page;
        }

        if (typeof initCustomDropdowns === 'function') initCustomDropdowns();   // dropdowns in the create/edit modal
        initEmployeeSearch();

        // Dulu: menunggu /api/modules selesai BARU meminta daftar karyawan (dua perjalanan berurutan). Kini keduanya berangkat bersamaan;
        // filter yang dipulihkan sudah ada di EMP_F, jadi daftar tidak bergantung pada opsi Module. Centang Module disinkronkan sesudahnya.
        const modulesReady = loadModuleFilterOptions();
        ehfSyncAll();
        toggleResetFilters();
        fetchEmployees(getCurrentFilters(), currentPage);
        modulesReady.then(() => ehfSyncAll());

        // Dari External → Consultants → Add Consultant (?create=external): buka formulir dengan Employee Group = EXTERNAL.
        if (new URLSearchParams(location.search).get('create') === 'external' && typeof openCreateModal === 'function') {
            openCreateModal();
            document.getElementById('modalTitle').textContent = 'Create External Consultant';
            if (typeof setCustomDropdownValue === 'function') setCustomDropdownValue('employeeGroup', 'EXTERNAL');
            document.getElementById('employeeGroup').value = 'EXTERNAL';
        }

        // Teleport menu ke body agar tidak ter-clip oleh overflow-x-hidden pada <main>
        const menu = document.getElementById('floatingEmpMenu');
        if (menu) document.body.appendChild(menu);
    });

    // Populate the Module header filter from /api/modules — dynamic because the module list can change
    // at any time through Master Module, so it is not hard-coded in the blade.
    async function loadModuleFilterOptions() {
        try {
            const response = await fetch('/api/modules?is_active=1', {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            });
            const data = await response.json();
            if (data.success) ehfSetOptions('modules', data.data.map(mod => mod.name));
        } catch (err) {
            console.warn('[Employee Filter] failed to load modules:', err.message);
        }
    }

    let _empMenuId = null, _empMenuName = null, _empMenuRoles = null, _empMenuEci = '';

    function openEmpMenu(event, id) {
        event.stopPropagation();
        const data    = _empRowData.get(Number(id)) ?? { name: '-', roleIds: [] };
        _empMenuId    = id;
        _empMenuName  = data.name;
        _empMenuRoles = data.roleIds;
        _empMenuEci   = data.eci || '';
        const menu = document.getElementById('floatingEmpMenu');
        const btn  = event.currentTarget;
        const rect = btn.getBoundingClientRect();
        menu.classList.remove('hidden');

        // Smart positioning: flip ke atas jika ruang bawah tidak cukup
        // Untuk position:fixed gunakan koordinat viewport langsung (tanpa scrollY)
        const mw = menu.offsetWidth;
        const mh = menu.scrollHeight;
        const spaceBelow = window.innerHeight - rect.bottom;
        const top = spaceBelow >= mh + 8
            ? rect.bottom + 4       // buka ke bawah
            : rect.top - mh - 4;   // flip ke atas
        menu.style.top  = Math.max(4, top) + 'px';
        menu.style.left = Math.max(8, Math.min(rect.right - mw, window.innerWidth - mw - 8)) + 'px';
    }

    function closeEmpMenu() {
        document.getElementById('floatingEmpMenu').classList.add('hidden');
    }

    function empMenuChangePassword() {
        closeEmpMenu();
        openChangePasswordModal(_empMenuId, _empMenuName);
    }
    function empMenuChangeEci() {
        closeEmpMenu();
        openChangeEciModal(_empMenuId, _empMenuName, _empMenuEci);
    }
    function empMenuChangeRole() {
        closeEmpMenu();
        openChangeRoleModal(_empMenuId, _empMenuName, _empMenuRoles);
    }
    function empMenuDelete() {
        closeEmpMenu();
        deleteEmployee(_empMenuId);
    }

    document.addEventListener('click', closeEmpMenu);
</script>

{{-- Floating action menu (fixed position to avoid table stacking context) --}}
@if($can('master.employee.action'))
<div id="floatingEmpMenu" class="hidden fixed z-[9999] w-44 bg-white border border-gray-200 rounded-lg shadow-xl py-1" onclick="event.stopPropagation()">
    <button onclick="empMenuChangePassword()" class="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition-all">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 text-blue-500">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 0 1 3 3m3 0a6 6 0 0 1-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 0 1 21.75 8.25Z"/>
        </svg>
        Change Password
    </button>
    <button onclick="empMenuChangeEci()" class="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition-all">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 text-amber-500">
            <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 3.75H6A2.25 2.25 0 0 0 3.75 6v1.5M16.5 3.75H18A2.25 2.25 0 0 1 20.25 6v1.5m0 9V18A2.25 2.25 0 0 1 18 20.25h-1.5m-9 0H6A2.25 2.25 0 0 1 3.75 18v-1.5M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
        </svg>
        Change ECI
    </button>
    <button onclick="empMenuChangeRole()" class="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition-all">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 text-purple-500">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"/>
        </svg>
        Change Role
    </button>
    <div class="border-t border-gray-100 my-1"></div>
    <button onclick="empMenuDelete()" class="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-600 hover:bg-red-50 transition-all">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"/>
        </svg>
        Delete
    </button>
</div>
@endif

@endsection