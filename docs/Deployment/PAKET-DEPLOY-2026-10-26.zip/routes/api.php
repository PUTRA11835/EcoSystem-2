<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\EmployeeBasicDataController;
use App\Http\Controllers\EmployeeAddressController;
use App\Http\Controllers\EmployeeIdentificationController;
use App\Http\Controllers\EmployeeFamilyController;
use App\Http\Controllers\EmployeeEducationController;
use App\Http\Controllers\EmployeeQualificationController;
use App\Http\Controllers\EmployeeContractController;
use App\Http\Controllers\EmployeeBankController;
use App\Http\Controllers\EmployeePaymentController;
use App\Http\Controllers\EmployeeSalaryComponentController;
use App\Http\Controllers\EmployeeAttachmentController;
use App\Http\Controllers\EmployeeCompensationController;
use App\Http\Controllers\EmployeeHrProfileController;
use App\Http\Controllers\EmployeeEngagementController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CustomerBasicDataController;
use App\Http\Controllers\CustomerAddressController;
use App\Http\Controllers\CustomerContactController;
use App\Http\Controllers\CustomerIdentificationController;
use App\Http\Controllers\CustomerBankController;
use App\Http\Controllers\CustomerAttachmentController;
use App\Http\Controllers\CustomerHistoryController;
use App\Http\Controllers\CustomerCredentialController;
use App\Http\Controllers\CustomerGroupController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\TicketMessageController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\TimesheetController;
use App\Http\Controllers\TicketActivityLogController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\StagingTicketController;
use App\Http\Controllers\MandaysController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PushSubscriptionController;
use App\Http\Controllers\ActivityLogController;
use App\Http\Controllers\LoginLogController;
use App\Http\Controllers\AdminSessionController;
use App\Http\Controllers\AdminJobController;
use App\Http\Controllers\AdminBackupController;
use App\Http\Controllers\AdminNotificationSoundController;
use App\Http\Controllers\TicketMigrationController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\ModuleGroupController;
use App\Http\Controllers\EmployeeModuleController;
use App\Http\Controllers\ModuleLeadController;

// ==================== HEALTH CHECK (public, no auth) ====================
Route::get('/health', function () {
    $checks = [];
    $status = 'ok';

    try {
        \Illuminate\Support\Facades\DB::connection()->getPdo();
        $checks['database'] = 'ok';
    } catch (\Throwable $e) {
        $checks['database'] = 'error';
        $status = 'degraded';
    }

    try {
        $queueSize = \Illuminate\Support\Facades\DB::table('jobs')->count();
        $failedCount = \Illuminate\Support\Facades\DB::table('failed_jobs')->count();
        $checks['queue_pending'] = $queueSize;
        $checks['queue_failed'] = $failedCount;
    } catch (\Throwable $e) {
        $checks['queue'] = 'unavailable';
    }

    return response()->json([
        'status'    => $status,
        'timestamp' => now()->toISOString(),
        'checks'    => $checks,
    ], $status === 'ok' ? 200 : 503);
})->name('health');

Route::middleware(['web'])->group(function () {

    // ==================== AUTH ROUTES (PUBLIC — no session required) ====================
    Route::prefix('auth')->group(function () {
        Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
    });

    // ==================== PROTECTED ROUTES (requires valid session) ====================
    Route::middleware(['auth.session'])->group(function () {

    // ==================== EMPLOYEE ROUTES ====================

    // Main Employee endpoints
    Route::prefix('employees')->group(function () {
        Route::get('/', [EmployeeController::class, 'getData']);
        Route::post('/', [EmployeeController::class, 'store'])->middleware('menu:master.employee.create');
        Route::get('/roles', [EmployeeController::class, 'getRoles']);
        Route::get('/mentionable', [EmployeeController::class, 'getMentionable']);
        Route::get('/{id}', [EmployeeController::class, 'getDetail'])->middleware('employee.section:basic_data,view');
        Route::get('/{id}/header', [EmployeeController::class, 'headerData'])->middleware('employee.section:basic_data,view');

        // Aksi terhadap record employee-nya sendiri (bukan section) — hanya
        // dari halaman Master > Employee, tidak pernah dari My Profile.
        Route::put('/{id}', [EmployeeController::class, 'update'])->middleware('menu:master.employee.action');
        Route::delete('/{id}', [EmployeeController::class, 'destroy'])->middleware('menu:master.employee.action');
        Route::post('/{id}/delete', [EmployeeController::class, 'destroy'])->middleware('menu:master.employee.action');
        Route::patch('/{id}/change-password', [EmployeeController::class, 'changePassword'])->middleware('menu:master.employee.action');
        Route::patch('/{id}/change-role', [EmployeeController::class, 'changeRole'])->middleware('menu:master.employee.action');
        // Ganti ECI (kode karyawan): wajib konfirmasi kata sandi penggantinya; dibatasi laju agar kata sandi tak bisa ditebak lewat sini.
        Route::patch('/{id}/change-eci', [EmployeeController::class, 'changeEci'])->middleware(['menu:master.employee.action', 'throttle:10,1']);
    });

    // Employee Basic Data endpoints
    Route::prefix('employees/{employeeId}')->group(function () {
        Route::get('/basic-data', [EmployeeBasicDataController::class, 'show'])->middleware('employee.section:basic_data,view');
        Route::post('/basic-data', [EmployeeBasicDataController::class, 'store'])->middleware('employee.section:basic_data');
        Route::delete('/basic-data', [EmployeeBasicDataController::class, 'destroy'])->middleware('employee.section:basic_data');
        Route::post('/basic-data/delete', [EmployeeBasicDataController::class, 'destroy'])->middleware('employee.section:basic_data');
    });

    // Employee Address endpoints
    Route::middleware(['auth.session'])->group(function () {
        Route::get('/employees/{employeeId}/addresses', [EmployeeAddressController::class, 'index'])->middleware('employee.section:address,view');
        Route::get('/employees/{employeeId}/addresses/{addressId}', [EmployeeAddressController::class, 'show'])->middleware('employee.section:address,view');
        Route::post('/employees/{employeeId}/addresses', [EmployeeAddressController::class, 'store'])->middleware('employee.section:address,create');
        Route::put('/employees/{employeeId}/addresses/{addressId}', [EmployeeAddressController::class, 'update'])->middleware('employee.section:address');
        Route::delete('/employees/{employeeId}/addresses/{addressId}', [EmployeeAddressController::class, 'destroy'])->middleware('employee.section:address,delete');
        Route::post('/employees/{employeeId}/addresses/{addressId}/delete', [EmployeeAddressController::class, 'destroy'])->middleware('employee.section:address,delete');
        Route::patch('/employees/{employeeId}/addresses/{addressId}/set-primary', [EmployeeAddressController::class, 'setPrimary'])->middleware('employee.section:address');

        // Referensi wilayah Indonesia — dropdown alamat cascading
        // (Region → City → District → Rural/Urban Village).
        Route::get('/regions/children', [\App\Http\Controllers\RegionController::class, 'children']);
    });

    // Employee Identification endpoints
    Route::prefix('employees/{employeeId}/identifications')->group(function () {
        Route::get('/', [EmployeeIdentificationController::class, 'index'])->middleware('employee.section:identification,view');
        Route::post('/', [EmployeeIdentificationController::class, 'store'])->middleware('employee.section:identification,create');
        Route::get('/{identificationId}', [EmployeeIdentificationController::class, 'show'])->middleware('employee.section:identification,view');
        Route::put('/{identificationId}', [EmployeeIdentificationController::class, 'update'])->middleware('employee.section:identification');
        Route::delete('/{identificationId}', [EmployeeIdentificationController::class, 'destroy'])->middleware('employee.section:identification,delete');
        Route::post('/{identificationId}/delete', [EmployeeIdentificationController::class, 'destroy'])->middleware('employee.section:identification,delete');
    });

    // Employee Family endpoints
    Route::prefix('employees/{employeeId}')->group(function () {
        Route::get('/family', [EmployeeFamilyController::class, 'index'])->middleware('employee.section:family,view');
        Route::get('/family/statistics', [EmployeeFamilyController::class, 'statistics'])->middleware('employee.section:family,view');
        Route::get('/family/{familyId}', [EmployeeFamilyController::class, 'show'])->middleware('employee.section:family,view');
        Route::post('/family', [EmployeeFamilyController::class, 'store'])->middleware('employee.section:family,create');
        Route::put('/family/{familyId}', [EmployeeFamilyController::class, 'update'])->middleware('employee.section:family');
        Route::delete('/family/{familyId}', [EmployeeFamilyController::class, 'destroy'])->middleware('employee.section:family,delete');
        Route::post('/family/{familyId}/delete', [EmployeeFamilyController::class, 'destroy'])->middleware('employee.section:family,delete');
    });

    // Employee Education endpoints
    Route::prefix('employees/{employeeId}/education')->group(function () {
        Route::get('/', [EmployeeEducationController::class, 'index'])->middleware('employee.section:education,view');
        Route::get('/{educationId}', [EmployeeEducationController::class, 'show'])->middleware('employee.section:education,view');
        Route::post('/', [EmployeeEducationController::class, 'store'])->middleware('employee.section:education,create');
        Route::put('/{educationId}', [EmployeeEducationController::class, 'update'])->middleware('employee.section:education');
        Route::delete('/{educationId}', [EmployeeEducationController::class, 'destroy'])->middleware('employee.section:education,delete');
        Route::post('/{educationId}/delete', [EmployeeEducationController::class, 'destroy'])->middleware('employee.section:education,delete');
    });

    // Employee Qualification endpoints
    Route::prefix('employees/{employeeId}/qualification')->group(function () {
        Route::get('/', [EmployeeQualificationController::class, 'index'])->middleware('employee.section:qualification,view');
        Route::get('/{qualificationId}', [EmployeeQualificationController::class, 'show'])->middleware('employee.section:qualification,view');
        Route::post('/', [EmployeeQualificationController::class, 'store'])->middleware('employee.section:qualification,create');
        Route::put('/{qualificationId}', [EmployeeQualificationController::class, 'update'])->middleware('employee.section:qualification');
        Route::delete('/{qualificationId}', [EmployeeQualificationController::class, 'destroy'])->middleware('employee.section:qualification,delete');
        Route::post('/{qualificationId}/delete', [EmployeeQualificationController::class, 'destroy'])->middleware('employee.section:qualification,delete');
    });

    // Employee Contract endpoints
    Route::prefix('employees/{employeeId}/contract')->group(function () {
        Route::get('/', [EmployeeContractController::class, 'index'])->middleware('employee.section:contract,view');
        Route::get('/{contractId}', [EmployeeContractController::class, 'show'])->middleware('employee.section:contract,view');
        Route::post('/', [EmployeeContractController::class, 'store'])->middleware('employee.section:contract,create');
        Route::put('/{contractId}', [EmployeeContractController::class, 'update'])->middleware('employee.section:contract');
        Route::delete('/{contractId}', [EmployeeContractController::class, 'destroy'])->middleware('employee.section:contract,delete');
        Route::post('/{contractId}/delete', [EmployeeContractController::class, 'destroy'])->middleware('employee.section:contract,delete');
    });

    // Employee Bank endpoints
    Route::prefix('employees/{employeeId}/bank')->group(function () {
        // GET dijaga juga (sebelumnya terbuka bagi akun mana pun): diri sendiri → my-profile.section.bank.view, orang lain → employee|external.section.bank.view.
        Route::get('/', [EmployeeBankController::class, 'index'])->middleware('employee.section:bank,view');
        Route::get('/{bankId}', [EmployeeBankController::class, 'show'])->middleware('employee.section:bank,view');
        Route::post('/', [EmployeeBankController::class, 'store'])->middleware('employee.section:bank,create');
        Route::put('/{bankId}', [EmployeeBankController::class, 'update'])->middleware('employee.section:bank');
        Route::delete('/{bankId}', [EmployeeBankController::class, 'destroy'])->middleware('employee.section:bank,delete');
        Route::post('/{bankId}/delete', [EmployeeBankController::class, 'destroy'])->middleware('employee.section:bank,delete');
    });

    // Employee HR Profile endpoints (H3.5). Hanya GET/POST (verb DELETE diblokir edge production).
    // GET butuh izin .view; semua POST butuh .update (target diri sendiri → my-profile.*, lain → employee.*).
    // Tanda tangan: hanya pemilik yang boleh unggah (dicek di controller).
    Route::prefix('employees/{employeeId}/hr-profile')->group(function () {
        Route::get('/', [EmployeeHrProfileController::class, 'show'])->middleware('employee.section:hr_profile,view');
        Route::post('/', [EmployeeHrProfileController::class, 'save'])->middleware('employee.section:hr_profile');
        Route::get('/photo', [EmployeeHrProfileController::class, 'photo'])->middleware('employee.section:hr_profile,view');
        Route::get('/signature', [EmployeeHrProfileController::class, 'signature'])->middleware('employee.section:hr_profile,view');
        Route::post('/photo', [EmployeeHrProfileController::class, 'uploadPhoto'])->middleware(['employee.section:hr_profile', 'throttle:30,1']);
        Route::post('/photo/delete', [EmployeeHrProfileController::class, 'deletePhoto'])->middleware(['employee.section:hr_profile', 'throttle:30,1']);
        Route::post('/signature', [EmployeeHrProfileController::class, 'uploadSignature'])->middleware(['employee.section:hr_profile', 'throttle:30,1']);
        Route::post('/signature/delete', [EmployeeHrProfileController::class, 'deleteSignature'])->middleware(['employee.section:hr_profile', 'throttle:30,1']);
    });

    // Employee Compensation endpoints (Payroll; HC-D21): penanda pajak & BPJS (PTKP, BPJS, ikut payroll) + ringkasan gaji.
    // Komponen gaji sendiri diedit di kotak Salary Components (employee.section.salary, di atas). Hanya GET/POST.
    // GET butuh .view; POST butuh .update. Tidak ada padanan my-profile (gaji tidak diedit pemilik).
    Route::prefix('employees/{employeeId}/compensation')->group(function () {
        Route::get('/', [EmployeeCompensationController::class, 'show'])->middleware('employee.section:compensation,view');
        Route::post('/tax', [EmployeeCompensationController::class, 'saveTax'])->middleware(['employee.section:compensation', 'throttle:60,1']);
    });

    // Employee Engagement endpoints — konsultan External (HC-D47). Hanya GET/POST. Tarif butuh izin terpisah
    // (dicek di controller). Tidak ada padanan my-profile: konsultan tidak mengakses blok ini untuk dirinya sendiri.
    Route::prefix('employees/{employeeId}/engagement')->group(function () {
        Route::get('/', [EmployeeEngagementController::class, 'show'])->middleware('employee.section:engagement,view');
        Route::post('/', [EmployeeEngagementController::class, 'save'])->middleware(['employee.section:engagement', 'throttle:60,1']);
    });

    // Salary Components — komponen gaji aktif karyawan (sumber utama payroll, BPJS, referensi kontrak).
    // Tidak ada padanan my-profile: pemilik tidak mengelola komponen gajinya sendiri.
    Route::prefix('employees/{employeeId}/salary-components')->group(function () {
        Route::get('/', [EmployeeSalaryComponentController::class, 'index'])->middleware('employee.section:salary,view');
        Route::post('/', [EmployeeSalaryComponentController::class, 'store'])->middleware('employee.section:salary,create');
        Route::put('/{componentId}', [EmployeeSalaryComponentController::class, 'update'])->middleware('employee.section:salary');
        Route::delete('/{componentId}', [EmployeeSalaryComponentController::class, 'destroy'])->middleware('employee.section:salary,delete');
        Route::post('/{componentId}/delete', [EmployeeSalaryComponentController::class, 'destroy'])->middleware('employee.section:salary,delete');
    });

    // My Profile recaps — SELF ONLY (the employee id is the session's, never a URL parameter). Read-only; HR changes
    // go through Contracts / Payroll. Deliberately not under employee.section.salary, which stays HR's editing gate.
    Route::prefix('profile')->group(function () {
        Route::get('/salary-summary', [\App\Http\Controllers\ProfileCompensationController::class, 'salarySummary']);
        // The signing state of my contracts (stage wording + link), for the Contract tab of My Profile.
        Route::get('/contract-signing', [\App\Http\Controllers\MyContractController::class, 'mine']);
        Route::get('/paystub-summary', [\App\Http\Controllers\ProfileCompensationController::class, 'paystubSummary'])->middleware('menu:general.my-paystub');
    });

    // Employee Payment endpoints
    Route::prefix('employees/{employeeId}/payment')->group(function () {
        // GET dijaga juga (lihat catatan pada Bank di atas).
        Route::get('/', [EmployeePaymentController::class, 'index'])->middleware('employee.section:payment,view');
        Route::get('/{paymentId}', [EmployeePaymentController::class, 'show'])->middleware('employee.section:payment,view');
        Route::post('/', [EmployeePaymentController::class, 'store'])->middleware('employee.section:payment,create');
        Route::put('/{paymentId}', [EmployeePaymentController::class, 'update'])->middleware('employee.section:payment');
        Route::delete('/{paymentId}', [EmployeePaymentController::class, 'destroy'])->middleware('employee.section:payment,delete');
        Route::post('/{paymentId}/delete', [EmployeePaymentController::class, 'destroy'])->middleware('employee.section:payment,delete');
    });

    // Employee Attachment endpoints
    Route::prefix('employees/{employeeId}/attachments')->group(function () {
        Route::get('/', [EmployeeAttachmentController::class, 'index'])->middleware('employee.section:attachment,view');
        Route::post('/', [EmployeeAttachmentController::class, 'store'])->middleware('employee.section:attachment,create');
        Route::delete('/{attachmentId}', [EmployeeAttachmentController::class, 'destroy'])->middleware('employee.section:attachment,delete');
        Route::post('/{attachmentId}/delete', [EmployeeAttachmentController::class, 'destroy'])->middleware('employee.section:attachment,delete');
    });

    // Employee Module endpoints
    Route::prefix('employees/{employeeId}/modules')->group(function () {
        Route::get('/', [EmployeeModuleController::class, 'index']);
        // Penugasan module ke employee — murni master data, tidak pernah
        // dipanggil dari My Profile, jadi cukup master.employee.action.
        Route::post('/sync', [EmployeeModuleController::class, 'sync'])->middleware('menu:master.employee.action');
        Route::post('/attach', [EmployeeModuleController::class, 'attach'])->middleware('menu:master.employee.action');
        Route::delete('/{moduleId}', [EmployeeModuleController::class, 'detach'])->middleware('menu:master.employee.action');
        Route::post('/{moduleId}/delete', [EmployeeModuleController::class, 'detach'])->middleware('menu:master.employee.action');
    });

    // Module master data endpoints
    Route::prefix('modules')->group(function () {
        Route::get('/', [ModuleController::class, 'index']);
        Route::post('/', [ModuleController::class, 'store']);
        Route::get('/overview', [ModuleController::class, 'overview']);   // lead + member semua module sekaligus (didaftarkan SEBELUM /{id})
        Route::get('/{id}', [ModuleController::class, 'show']);
        Route::get('/{id}/members', [ModuleController::class, 'members']);
        Route::put('/{id}', [ModuleController::class, 'update']);
        Route::delete('/{id}', [ModuleController::class, 'destroy']);
        Route::post('/{id}/delete', [ModuleController::class, 'destroy']);
    });

    // Module Group master data endpoints — pengelompokan module (mis. "Logistik" berisi ABAP, FI, dll).
    Route::prefix('module-groups')->group(function () {
        Route::get('/', [ModuleGroupController::class, 'index']);
        Route::post('/', [ModuleGroupController::class, 'store']);
        Route::get('/{id}', [ModuleGroupController::class, 'show']);
        Route::put('/{id}', [ModuleGroupController::class, 'update']);
        Route::delete('/{id}', [ModuleGroupController::class, 'destroy']);
        Route::post('/{id}/delete', [ModuleGroupController::class, 'destroy']);
    });

    // Module Lead endpoints — siapa yang jadi lead untuk tiap module.
    // Gating disamakan dengan penugasan module ke employee (menu:master.employee.action).
    Route::get('/module-leads/search-employees', [ModuleLeadController::class, 'searchEmployees']);
    Route::prefix('modules/{moduleId}/leads')->group(function () {
        Route::get('/', [ModuleLeadController::class, 'index']);
        Route::post('/', [ModuleLeadController::class, 'store'])->middleware('menu:master.employee.action');
        Route::delete('/{employeeId}', [ModuleLeadController::class, 'destroy'])->middleware('menu:master.employee.action');
        Route::post('/{employeeId}/delete', [ModuleLeadController::class, 'destroy'])->middleware('menu:master.employee.action');
    });

// ==================== CUSTOMER ROUTES ====================

    // Main Customer endpoints
    Route::prefix('customers')->group(function () {
        Route::get('/', [CustomerController::class, 'getData']);
        Route::post('/', [CustomerController::class, 'store'])->middleware('menu:master.customer.create');
        Route::get('/search', [CustomerController::class, 'search']);
        Route::get('/statistics', [CustomerController::class, 'statistics']);
        Route::get('/top-level', [CustomerController::class, 'topLevel']);
        Route::get('/sales-employees', [CustomerController::class, 'salesEmployees']);
        Route::get('/grouping-data', [CustomerController::class, 'getGroupingData']);
        Route::get('/{id}', [CustomerController::class, 'show']);
        Route::get('/{id}/header', [CustomerController::class, 'headerData']);
        Route::get('/{id}/end-customers', [CustomerController::class, 'endCustomers']);
        // Aksi terhadap record customer-nya sendiri — menu 'Actions (Edit/Delete)'
        // di bawah Master > Business Partner. Data section-nya dijaga terpisah
        // lewat middleware customer.section (lihat blok-blok di bawah).
        Route::put('/{id}', [CustomerController::class, 'update'])->middleware('menu:master.customer.action');
        Route::delete('/{id}', [CustomerController::class, 'destroy'])->middleware('menu:master.customer.action');
        Route::post('/{id}/delete', [CustomerController::class, 'destroy'])->middleware('menu:master.customer.action');
        Route::post('/{id}/soft-delete', [CustomerController::class, 'softDelete'])->middleware('menu:master.customer.action');
        Route::post('/{id}/restore', [CustomerController::class, 'restore'])->middleware('menu:master.customer.action');
    });

    // Customer Group endpoints (struktural grouping)
    Route::prefix('customer-groups')->group(function () {
        Route::get('/', [CustomerGroupController::class, 'index']);
        Route::post('/', [CustomerGroupController::class, 'store'])->middleware('menu:master.customer.create');
        Route::get('/grouping-data', [CustomerGroupController::class, 'groupingData']);
        Route::get('/available-customers', [CustomerGroupController::class, 'availableCustomers']);
        Route::put('/{id}', [CustomerGroupController::class, 'update'])->middleware('menu:master.customer.action');
        Route::delete('/{id}', [CustomerGroupController::class, 'destroy'])->middleware('menu:master.customer.action');
        Route::post('/{id}/delete', [CustomerGroupController::class, 'destroy'])->middleware('menu:master.customer.action');
        Route::post('/{id}/members', [CustomerGroupController::class, 'addMember'])->middleware('menu:master.customer.action');
        Route::delete('/{id}/members/{customerId}', [CustomerGroupController::class, 'removeMember'])->middleware('menu:master.customer.action');
        Route::post('/{id}/members/{customerId}/delete', [CustomerGroupController::class, 'removeMember'])->middleware('menu:master.customer.action');
    });

    // Customer Basic Data endpoints
    Route::prefix('customers/{customerId}/basic-data')->group(function () {
        Route::get('/', [CustomerBasicDataController::class, 'show']);
        Route::post('/', [CustomerBasicDataController::class, 'store'])->middleware('customer.section:basic_data');
        Route::delete('/', [CustomerBasicDataController::class, 'destroy'])->middleware('customer.section:basic_data');
        Route::post('/delete', [CustomerBasicDataController::class, 'destroy'])->middleware('customer.section:basic_data');
    });

    // Customer Address endpoints
    Route::prefix('customers/{customerId}/addresses')->group(function () {
        Route::get('/', [CustomerAddressController::class, 'index']);
        Route::get('/{addressId}', [CustomerAddressController::class, 'show']);
        Route::post('/', [CustomerAddressController::class, 'store'])->middleware('customer.section:address');
        Route::put('/{addressId}', [CustomerAddressController::class, 'update'])->middleware('customer.section:address');
        Route::delete('/{addressId}', [CustomerAddressController::class, 'destroy'])->middleware('customer.section:address');
        Route::post('/{addressId}/delete', [CustomerAddressController::class, 'destroy'])->middleware('customer.section:address');
    });

    // Customer Contact endpoints
    Route::prefix('customers/{customerId}/contacts')->group(function () {
        Route::get('/', [CustomerContactController::class, 'index']);
        Route::get('/{contactId}', [CustomerContactController::class, 'show']);
        Route::post('/', [CustomerContactController::class, 'store'])->middleware('customer.section:contact');
        Route::put('/{contactId}', [CustomerContactController::class, 'update'])->middleware('customer.section:contact');
        Route::delete('/{contactId}', [CustomerContactController::class, 'destroy'])->middleware('customer.section:contact');
        Route::post('/{contactId}/delete', [CustomerContactController::class, 'destroy'])->middleware('customer.section:contact');
        // Jarvies login management per contact person
        Route::post('/{contactId}/create-login', [CustomerContactController::class, 'createLogin'])->middleware('customer.section:contact');
        Route::delete('/{contactId}/revoke-login', [CustomerContactController::class, 'revokeLogin'])->middleware('customer.section:contact');
        Route::post('/{contactId}/revoke-login', [CustomerContactController::class, 'revokeLogin'])->middleware('customer.section:contact');
        Route::patch('/{contactId}/toggle-view-all', [CustomerContactController::class, 'toggleViewAllTickets'])->middleware('customer.section:contact');
    });

    // Customer Identification endpoints
    Route::prefix('customers/{customerId}/identifications')->group(function () {
        Route::get('/', [CustomerIdentificationController::class, 'index']);
        Route::get('/{identificationId}', [CustomerIdentificationController::class, 'show']);
        Route::post('/', [CustomerIdentificationController::class, 'store'])->middleware('customer.section:identification');
        Route::put('/{identificationId}', [CustomerIdentificationController::class, 'update'])->middleware('customer.section:identification');
        Route::delete('/{identificationId}', [CustomerIdentificationController::class, 'destroy'])->middleware('customer.section:identification');
        Route::post('/{identificationId}/delete', [CustomerIdentificationController::class, 'destroy'])->middleware('customer.section:identification');
    });

    // Customer Bank endpoints
    Route::prefix('customers/{customerId}/banks')->group(function () {
        Route::get('/', [CustomerBankController::class, 'index']);
        Route::get('/{bankId}', [CustomerBankController::class, 'show']);
        Route::post('/', [CustomerBankController::class, 'store'])->middleware('customer.section:bank');
        Route::put('/{bankId}', [CustomerBankController::class, 'update'])->middleware('customer.section:bank');
        Route::delete('/{bankId}', [CustomerBankController::class, 'destroy'])->middleware('customer.section:bank');
        Route::post('/{bankId}/delete', [CustomerBankController::class, 'destroy'])->middleware('customer.section:bank');
    });

    // Customer Attachment endpoints
    Route::prefix('customers/{customerId}/attachments')->group(function () {
        Route::get('/', [CustomerAttachmentController::class, 'index']);
        Route::get('/{attachmentId}', [CustomerAttachmentController::class, 'show']);
        Route::post('/', [CustomerAttachmentController::class, 'store'])->middleware('customer.section:attachment');
        Route::put('/{attachmentId}', [CustomerAttachmentController::class, 'update'])->middleware('customer.section:attachment');
        Route::delete('/{attachmentId}', [CustomerAttachmentController::class, 'destroy'])->middleware('customer.section:attachment');
        Route::post('/{attachmentId}/delete', [CustomerAttachmentController::class, 'destroy'])->middleware('customer.section:attachment');
        Route::get('/{attachmentId}/download', [CustomerAttachmentController::class, 'download']);
    });

    // Customer Credential endpoints
    Route::get('customers/{customerId}/credential', [CustomerCredentialController::class, 'show']);
    Route::post('customers/{customerId}/credential', [CustomerCredentialController::class, 'store'])->middleware('customer.section:credential');

    // Customer History endpoints
    Route::prefix('customers/{customerId}/history')->group(function () {
        Route::get('/', [CustomerHistoryController::class, 'index']);
        Route::post('/', [CustomerHistoryController::class, 'store'])->middleware('customer.section:history');
        Route::get('/statistics', [CustomerHistoryController::class, 'statistics']);
        Route::delete('/cleanup', [CustomerHistoryController::class, 'cleanup'])->middleware('customer.section:history');
    });

    // ==================== TASK (MY PIC TICKETS) ====================
    Route::get('/task', [\App\Http\Controllers\TaskController::class, 'list']);

    // ==================== CONSULTANT WORKLOAD ROUTES ====================
    Route::prefix('consultant-workload')->group(function () {
        Route::get('/', [\App\Http\Controllers\ConsultantWorkloadController::class, 'list']);
        Route::get('/tickets/{ticketId}/consultant-progress', [\App\Http\Controllers\ConsultantWorkloadController::class, 'getConsultantProgress']);
        Route::patch('/tickets/{ticketId}/consultant-progress', [\App\Http\Controllers\ConsultantWorkloadController::class, 'updateConsultantProgress']);
        Route::get('/{id}', [\App\Http\Controllers\ConsultantWorkloadController::class, 'detail']);
    });

    // ==================== STAGING TICKET ROUTES ====================
    Route::prefix('staging-tickets')->group(function () {
        Route::get('/statistics', [StagingTicketController::class, 'statistics']);
        Route::get('/', [StagingTicketController::class, 'index']);
        Route::post('/', [StagingTicketController::class, 'store']);
        Route::get('/{id}', [StagingTicketController::class, 'show']);
        Route::get('/{id}/preview-body', [StagingTicketController::class, 'previewBody']);
        Route::get('/{id}/email-attachments', [StagingTicketController::class, 'emailAttachments']);
        Route::get('/{id}/attachment-download', [StagingTicketController::class, 'emailAttachmentDownload']);
        Route::post('/{id}/approve', [StagingTicketController::class, 'approve']);
        Route::post('/{id}/reject', [StagingTicketController::class, 'reject']);
        Route::post('/{id}/analyze', [StagingTicketController::class, 'analyze']);
    });

    // ==================== TICKET ROUTES ====================
    Route::prefix('tickets')->group(function () {
        // Static routes first
        Route::get('/', [TicketController::class, 'index']);
        Route::get('/my', [TicketController::class, 'myTickets']);
        Route::get('/my-for-timesheet', [TicketController::class, 'myTicketsForTimesheet']);
        Route::get('/unassigned', [TicketController::class, 'unassignedTickets']);
        Route::get('/hidden', [TicketController::class, 'hiddenIndex']);
        Route::get('/latest-update', [TicketController::class, 'latestUpdate']);
        Route::get('/filter-options', [TicketController::class, 'filterOptions']);
        Route::get('/statistics', [TicketController::class, 'statistics']);
        Route::get('/pending-confirmations', [TicketController::class, 'pendingConfirmations']);
        Route::get('/pending-member-changes', [TicketController::class, 'pendingMemberChanges']);
        Route::get('/available-ticket-leads', [TicketController::class, 'getAvailableTicketLeads']);
        Route::post('/', [TicketController::class, 'store']);
        Route::post('/helpdesk-create', [TicketController::class, 'storeFromHelpdesk']);

        // Routes with specific names
        Route::get('/status/{status}', [TicketController::class, 'getByStatus']);
        Route::post('/confirm-assignment/{confirmationId}', [TicketController::class, 'confirmAssignment']);
        Route::post('/member-change-requests/{changeRequestId}/{action}', [TicketController::class, 'processMemberChangeRequest']);

        // Routes with {id} parameter last
        Route::get('/{id}', [TicketController::class, 'show']);
        Route::get('/{id}/mandays-history', [TicketController::class, 'getMandaysHistory']);
        Route::patch('/{id}/hide', [TicketController::class, 'hide']);
        Route::patch('/{id}/unhide', [TicketController::class, 'unhide']);
        Route::post('/{id}/take', [TicketController::class, 'takeTicket']);
        Route::post('/{id}/assign-ticket-lead', [TicketController::class, 'assignTicketLead']);
        Route::patch('/{id}/pic', [TicketController::class, 'updatePic']);
        Route::put('/{id}', [TicketController::class, 'update']);
        // POST alias untuk server yang memblokir method PUT/DELETE (ikuti pola /members/.../remove)
        Route::post('/{id}/update', [TicketController::class, 'update']);
        Route::put('/{id}/update-status', [TicketController::class, 'updateTicketStatus']);
        Route::put('/{id}/update-mandays', [TicketController::class, 'updateManDays']);
        Route::post('/{id}/members', [TicketController::class, 'addMember']);
        Route::delete('/{id}/members/{employeeId}', [TicketController::class, 'removeMember']);
        Route::post('/{id}/members/{employeeId}/remove', [TicketController::class, 'removeMember']);
        Route::post('/{id}/update-members', [TicketController::class, 'updateMembers']);
        Route::post('/{id}/request-member-change', [TicketController::class, 'requestMemberChange']);
        Route::delete('/{id}/request-member-removal/{employeeId}', [TicketController::class, 'requestMemberRemoval']);
        Route::post('/{id}/request-member-removal/{employeeId}/delete', [TicketController::class, 'requestMemberRemoval']);
        Route::delete('/{id}', [TicketController::class, 'destroy']);
        Route::post('/{id}/delete', [TicketController::class, 'destroy']);

        // Ticket Messages
        Route::get('/{ticketId}/messages', [TicketMessageController::class, 'index']);
        Route::post('/{ticketId}/messages', [TicketMessageController::class, 'store']);
        Route::post('/{ticketId}/customer-reply', [TicketMessageController::class, 'customerReply']);
        Route::put('/{ticketId}/messages/mark-all-read', [TicketMessageController::class, 'markAllRead']);
        Route::post('/{ticketId}/initiate-email', [TicketMessageController::class, 'initiateEmail']);
        Route::patch('/{ticketId}/messages/{messageId}/sla-message', [TicketMessageController::class, 'updateSlaMessage']);
        Route::post('/{ticketId}/messages/{messageId}/internal-note', [TicketMessageController::class, 'updateInternalNote']);
        Route::delete('/{ticketId}/messages/{messageId}/internal-note', [TicketMessageController::class, 'destroyInternalNote']);
        Route::post('/{ticketId}/messages/{messageId}/internal-note/delete', [TicketMessageController::class, 'destroyInternalNote']);

        // ==================== DELIVERABLE ROUTES ====================
        Route::get('/{id}/deliverables', [\App\Http\Controllers\TicketDeliverableController::class, 'index']);
        Route::post('/{id}/deliverables', [\App\Http\Controllers\TicketDeliverableController::class, 'store']);
        Route::patch('/{id}/deliverables/{delivId}', [\App\Http\Controllers\TicketDeliverableController::class, 'update']);
        Route::patch('/{id}/deliverables/{delivId}/send', [\App\Http\Controllers\TicketDeliverableController::class, 'send']);
        Route::delete('/{id}/deliverables/{delivId}', [\App\Http\Controllers\TicketDeliverableController::class, 'destroy']);
        Route::post('/{id}/deliverables/{delivId}/delete', [\App\Http\Controllers\TicketDeliverableController::class, 'destroy']);

        // Assign ticket to delivery support
        Route::get('/{id}/available-supports', [TicketController::class, 'getAvailableSupports']);
        Route::post('/{id}/assign-to-support', [TicketController::class, 'assignToSupport']);
        Route::post('/{id}/create-delivery-support', [TicketController::class, 'createDeliverySupport']);

        // ==================== MANDAYS ROUTES ====================
        // Shared utility
        Route::get('/{ticketId}/mandays/modules',  [MandaysController::class, 'getModules']);
        Route::get('/{ticketId}/mandays/history',  [MandaysController::class, 'getCustomerMandaysHistory']);
        Route::get('/{ticketId}/mandays/approved',             [MandaysController::class, 'getApprovedMandays']);
        Route::get('/{ticketId}/consultant-mandays/approved', [MandaysController::class, 'getApprovedConsultantMandays']);
        Route::get('/{ticketId}/mandays/version/{mandaysId}', [MandaysController::class, 'getCustomerMandaysVersionDetail']);

        // Customer Mandays — PIC
        Route::get('/{ticketId}/mandays/pic-draft', [MandaysController::class, 'getCustomerDraft']);
        Route::post('/{ticketId}/mandays/pic-draft', [MandaysController::class, 'saveCustomerDraft']);
        Route::post('/{ticketId}/mandays/pic-draft/submit', [MandaysController::class, 'submitCustomerDraft']);
        Route::delete('/{ticketId}/mandays/pic-draft', [MandaysController::class, 'deleteCustomerDraft']);

        // Customer Mandays — Helpdesk
        Route::get('/{ticketId}/mandays/hd-draft', [MandaysController::class, 'getHelpdeskDraft']);
        Route::put('/{ticketId}/mandays/hd-draft', [MandaysController::class, 'saveHelpdeskDraft']);
        Route::post('/{ticketId}/mandays/hd-draft/submit-chat', [MandaysController::class, 'submitToChat']);
        Route::post('/{ticketId}/mandays/hd-draft/approve', [MandaysController::class, 'approveCustomerMandays']);
        Route::post('/{ticketId}/mandays/hd-draft/cancel', [MandaysController::class, 'cancelCustomerMandays']);

        // Resolution Days — PIC + Head of Support
        Route::get('/{ticketId}/mandays/resolution', [MandaysController::class, 'getResolutionProposal']);
        Route::post('/{ticketId}/mandays/resolution', [MandaysController::class, 'saveResolutionProposal']);
        Route::post('/{ticketId}/mandays/resolution/submit', [MandaysController::class, 'submitResolutionProposal']);
        Route::post('/{ticketId}/mandays/resolution/approve', [MandaysController::class, 'approveResolutionProposal']);
    });

    // ==================== DELIVERY SUPPORT API ROUTES ====================
    Route::prefix('delivery/support')->group(function () {
        Route::get('/search', [\App\Http\Controllers\Delivery\DeliverySupportController::class, 'search']);
    });

    // ==================== CALENDAR/EVENT ROUTES ====================
    Route::prefix('events')->group(function () {
        Route::get('/', [CalendarController::class, 'getEvents']);
        Route::get('/statistics', [CalendarController::class, 'statistics']);
        Route::get('/{id}', [CalendarController::class, 'show']);
        Route::post('/', [CalendarController::class, 'store']);
        Route::put('/{id}', [CalendarController::class, 'update']);
        Route::delete('/{id}', [CalendarController::class, 'destroy']);
    });

    // ==================== TICKET ACTIVITY LOG ROUTES ====================
    Route::prefix('tickets/{ticketId}/activity-logs')->group(function () {
        Route::get('/',              [TicketActivityLogController::class, 'index']);
        Route::post('/',             [TicketActivityLogController::class, 'store']);
        Route::post('/{logId}/update', [TicketActivityLogController::class, 'update']);
        Route::post('/{logId}/delete', [TicketActivityLogController::class, 'destroy']);
    });

    // ==================== TIMESHEET ROUTES ====================
    
    // ==================== HR & GENERAL LEAVE & PERMIT API ====================
    Route::prefix('hr-general/leave-permit')->group(function () {
        Route::get('/employees-list',               [\App\Http\Controllers\HR\LeavePermitController::class, 'getEmployeesList'])->middleware('menu:hr_general.leave_permit');
        Route::get('/user-quotas',                      [\App\Http\Controllers\HR\LeavePermitController::class, 'getUserQuotas']);
        Route::get('/all-employees-quotas',            [\App\Http\Controllers\HR\LeavePermitController::class, 'getAllEmployeesQuotas'])->middleware('menu:hr_general.leave_permit');
        Route::get('/employee-quota-detail/{employee_id}', [\App\Http\Controllers\HR\LeavePermitController::class, 'getEmployeeQuotaDetail'])->middleware('menu:hr_general.leave_permit');
        
        Route::get('/master-types',                        [\App\Http\Controllers\HR\LeavePermitController::class, 'getMasterTypes']);
        Route::post('/master-types',                       [\App\Http\Controllers\HR\LeavePermitController::class, 'storeType'])->middleware('menu.can:hr_general.leave_permit.tab-types,create');
        Route::post('/master-types/{id}/update',            [\App\Http\Controllers\HR\LeavePermitController::class, 'updateType'])->middleware('menu.can:hr_general.leave_permit.tab-types,edit');
        Route::post('/master-types/{id}/toggle-active',     [\App\Http\Controllers\HR\LeavePermitController::class, 'toggleTypeActive'])->middleware('menu.can:hr_general.leave_permit.tab-types,edit');

        Route::get('/applications',               [\App\Http\Controllers\HR\LeavePermitController::class, 'getApplications']);
        Route::post('/applications',              [\App\Http\Controllers\HR\LeavePermitController::class, 'storeApplication']);
        Route::post('/applications/{id}/update',   [\App\Http\Controllers\HR\LeavePermitController::class, 'updateApplication']);
        Route::post('/applications/{id}/approve',  [\App\Http\Controllers\HR\LeavePermitController::class, 'approveApplication'])->middleware('menu.can:hr_general.leave_permit.tab-inbox,edit');
        Route::post('/applications/{id}/reject',   [\App\Http\Controllers\HR\LeavePermitController::class, 'rejectApplication'])->middleware('menu.can:hr_general.leave_permit.tab-inbox,edit');
        Route::post('/applications/{id}/revision', [\App\Http\Controllers\HR\LeavePermitController::class, 'requestRevision'])->middleware('menu.can:hr_general.leave_permit.tab-inbox,edit');
        
        Route::get('/reports', [\App\Http\Controllers\HR\LeavePermitController::class, 'getReport'])->middleware('menu:hr_general.leave_permit');
    });
    Route::prefix('timesheets')->group(function () {
        Route::get('/', [TimesheetController::class, 'index']);
        Route::get('/statistics', [TimesheetController::class, 'statistics']);
        Route::get('/submitted-for-approval', [TimesheetController::class, 'submittedForApproval']); // For heads to review
        Route::get('/my-projects', [TimesheetController::class, 'myProjects']);
        Route::get('/my-activities/all', [TimesheetController::class, 'allMyActivities']); // Get ALL assigned activities
        Route::get('/my-activities/{projectId}', [TimesheetController::class, 'myActivities']); // Get activities for specific project
        Route::get('/remaining-md', [TimesheetController::class, 'remainingMd']); // Remaining MD quota for a ticket
        Route::get('/my-late-exceptions', [TimesheetController::class, 'myLateExceptions']); // Approved late exception requests (not expired)
        Route::get('/valid-periods',      [TimesheetController::class, 'validPeriods']);      // Active window + late exceptions for the current user
        Route::post('/export', [TimesheetController::class, 'exportToExcel']);
        Route::get('/{id}', [TimesheetController::class, 'show']);
        Route::post('/', [TimesheetController::class, 'store']);
        Route::post('/{id}/update', [TimesheetController::class, 'update']);
        Route::post('/{id}/delete', [TimesheetController::class, 'destroy']);
        Route::post('/{id}/submit', [TimesheetController::class, 'submit']);
        Route::post('/{id}/approve', [TimesheetController::class, 'approve']);
        Route::post('/{id}/reject', [TimesheetController::class, 'reject']);
    });

    // ==================== REPORTING ROUTES ====================
    Route::prefix('reporting')->group(function () {
        Route::get('/timesheet-support', [\App\Http\Controllers\ReportingController::class, 'timesheetSupport']);
        Route::get('/current-period',    [\App\Http\Controllers\ReportingController::class, 'currentPeriod']);
        Route::post('/close-period',     [\App\Http\Controllers\ReportingController::class, 'closePeriod']);
        Route::get('/md-recap',          [\App\Http\Controllers\ReportingController::class, 'mdRecap']);
        Route::get('/collection-outlook', [\App\Http\Controllers\ReportingController::class, 'collectionOutlook']);
        // Ubah status penagihan TOP langsung dari matrix Collection Outlook.
        // Pakai POST (bukan PUT) — verb PUT/DELETE pernah diblok edge/WAF di production.
        Route::post('/collection-outlook/terms/{term}', [\App\Http\Controllers\ReportingController::class, 'collectionOutlookUpdateTerm'])
            ->middleware('menu:reporting.collection-outlook.edit');
        // Collection Outlook — Delivery Support (sumber TOP support)
        Route::get('/collection-outlook-support', [\App\Http\Controllers\ReportingController::class, 'collectionOutlookSupport']);
        Route::post('/collection-outlook-support/terms/{term}', [\App\Http\Controllers\ReportingController::class, 'collectionOutlookSupportUpdateTerm'])
            ->middleware('menu:reporting.collection-outlook-support.edit');
        Route::get('/ticketing-overview', [\App\Http\Controllers\ReportingController::class, 'ticketingOverview']);
        Route::get('/ticketing-overview/{customerId}', [\App\Http\Controllers\ReportingController::class, 'ticketingOverviewDetail']);
        Route::get('/ticket-by-module', [\App\Http\Controllers\ReportingController::class, 'ticketByModule']);
        // Diagram Report page (Grafik 1/2/3) — dummy charts on the page use hard-coded
        // sample data; only these three fetch live data.
        Route::get('/diagram-report/ticket-qty',           [\App\Http\Controllers\ReportingController::class, 'diagramTicketQty']);
        Route::get('/diagram-report/ticket-by-module',     [\App\Http\Controllers\ReportingController::class, 'diagramTicketByModule']);
        Route::get('/diagram-report/ticket-type-by-month', [\App\Http\Controllers\ReportingController::class, 'diagramTicketTypeByMonth']);
        Route::get('/diagram-report/ticket-by-module-type', [\App\Http\Controllers\ReportingController::class, 'diagramTicketByModuleType']);
        Route::get('/diagram-report/ticket-type-by-module-table', [\App\Http\Controllers\ReportingController::class, 'diagramTicketTypeByModuleTable']);
        Route::get('/diagram-report/ticket-by-module-current-period', [\App\Http\Controllers\ReportingController::class, 'diagramTicketByModuleCurrentPeriod']);
        Route::get('/diagram-report/ticket-by-type', [\App\Http\Controllers\ReportingController::class, 'diagramTicketByType']);
        Route::get('/diagram-report/ticket-by-cr-status', [\App\Http\Controllers\ReportingController::class, 'diagramTicketByCrStatus']);
        Route::get('/diagram-report/ticket-by-cr-per-month', [\App\Http\Controllers\ReportingController::class, 'diagramTicketByCrPerMonth']);
        Route::get('/diagram-report/ticket-closed-per-month', [\App\Http\Controllers\ReportingController::class, 'diagramTicketClosedPerMonth']);
        Route::get('/log-shifting', [\App\Http\Controllers\ReportingController::class, 'logShifting']);
        Route::get('/log-shifting/{ticketId}', [\App\Http\Controllers\ReportingController::class, 'logShiftingDetail']);
        Route::get('/resolution-days', [\App\Http\Controllers\ReportingController::class, 'resolutionDays']);
        // Consultant Assignment — daftar consultant yang tergabung di Delivery Project.
        // Izinnya diperiksa di controller lewat Employee::canAccessMenu().
        Route::get('/consultant-assignment', [\App\Http\Controllers\ReportingController::class, 'consultantAssignment']);
        Route::get('/consultant-assignment/filter-options', [\App\Http\Controllers\ReportingController::class, 'consultantAssignmentFilterOptions']);
    });

    // ==================== NOTIFICATION ROUTES ====================
    Route::prefix('notifications')->group(function () {
        Route::get('/',              [NotificationController::class, 'apiIndex']);
        Route::get('/unread-count',  [NotificationController::class, 'unreadCount']);
        Route::put('/read-all',      [NotificationController::class, 'markAllRead']);
        Route::put('/{id}/read',     [NotificationController::class, 'markRead']);
        Route::delete('/bulk-delete', [NotificationController::class, 'bulkDelete']);
        Route::post('/bulk-delete',  [NotificationController::class, 'bulkDelete']);
        Route::delete('/{id}',       [NotificationController::class, 'deleteOne']);
        Route::post('/{id}/delete',  [NotificationController::class, 'deleteOne']);
    });

    // ==================== WEB PUSH ROUTES ====================
    Route::prefix('push')->group(function () {
        Route::get('/vapid-public-key', [PushSubscriptionController::class, 'vapidPublicKey']);
        Route::post('/subscribe',       [PushSubscriptionController::class, 'subscribe']);
        Route::delete('/unsubscribe',   [PushSubscriptionController::class, 'unsubscribe']);
        Route::post('/unsubscribe',     [PushSubscriptionController::class, 'unsubscribe']);
        Route::post('/test',            [PushSubscriptionController::class, 'test']);
    });

    // ==================== EMAIL ROUTES ====================
    Route::prefix('email')->group(function () {
        Route::get('/inbox', [EmailController::class, 'inbox']);
        Route::post('/process-inbox', [EmailController::class, 'processInbox']);
        Route::post('/process-sent',  [EmailController::class, 'processSentItems']);
        Route::post('/send', [EmailController::class, 'send']);
        Route::post('/reply', [EmailController::class, 'reply']);
        Route::post('/messages/{messageId}/reprocess-attachments', [EmailController::class, 'reprocessAttachments']);
    });

    // ==================== PERIOD MANAGEMENT ROUTES ====================
    Route::prefix('periods')->group(function () {
        Route::get('/active',  [\App\Http\Controllers\PeriodManagementController::class, 'activePeriod']);
        Route::get('/closed',  [\App\Http\Controllers\PeriodManagementController::class, 'closedPeriods']);
        Route::post('/',       [\App\Http\Controllers\PeriodManagementController::class, 'store']);

        // Late exception request flow (2-level approval)
        Route::get('/my-exception-requests',   [\App\Http\Controllers\PeriodManagementController::class, 'myExceptionRequests']);
        Route::post('/exception-requests',     [\App\Http\Controllers\PeriodManagementController::class, 'createExceptionRequest']);
        Route::get('/exception-requests',      [\App\Http\Controllers\PeriodManagementController::class, 'listExceptionRequests']);
        Route::patch('/exception-requests/{exRequest}/head-decide', [\App\Http\Controllers\PeriodManagementController::class, 'headDecideRequest']);
        Route::patch('/exception-requests/{exRequest}/rpmo-decide', [\App\Http\Controllers\PeriodManagementController::class, 'rpmoDecideRequest']);

        Route::prefix('/{period}')->group(function () {
            // RPMO: global lifecycle
            Route::post('/open-global',  [\App\Http\Controllers\PeriodManagementController::class, 'openGlobal']);
            Route::post('/close-global', [\App\Http\Controllers\PeriodManagementController::class, 'closeGlobal']);
            Route::post('/force-close',  [\App\Http\Controllers\PeriodManagementController::class, 'forceCloseDomain']);
            // RPMO / Admin: edit dates & delete
            Route::patch('/dates',       [\App\Http\Controllers\PeriodManagementController::class, 'updateDates']);
            Route::delete('/',           [\App\Http\Controllers\PeriodManagementController::class, 'destroy']);
            Route::post('/delete',       [\App\Http\Controllers\PeriodManagementController::class, 'destroy']);
            // Heads: domain lifecycle
            Route::post('/open-domain',  [\App\Http\Controllers\PeriodManagementController::class, 'openDomain']);
            Route::post('/close-domain', [\App\Http\Controllers\PeriodManagementController::class, 'closeDomain']);
            // Audit logs (Admin + Heads + RPMO)
            Route::get('/audit-logs',    [\App\Http\Controllers\PeriodManagementController::class, 'auditLogs']);
        });
    });

    // ==================== ADMIN ROUTES ====================
    Route::prefix('admin')->group(function () {
        Route::get('/activity-logs', [ActivityLogController::class, 'getData']);
        Route::get('/audit-logs', [\App\Http\Controllers\AuditLogController::class, 'getData']);
        Route::get('/audit-logs/modules', [\App\Http\Controllers\AuditLogController::class, 'modules']);
        Route::get('/login-logs', [LoginLogController::class, 'getData']);

        // Session Management
        Route::get('/sessions', [AdminSessionController::class, 'index']);
        Route::delete('/sessions/{sessionId}', [AdminSessionController::class, 'destroy']);
        Route::post('/sessions/{sessionId}/delete', [AdminSessionController::class, 'destroy']);
        Route::delete('/sessions', [AdminSessionController::class, 'destroyAll']);
        Route::post('/sessions/delete-all', [AdminSessionController::class, 'destroyAll']);

        // DB Backup
        Route::get('/backup/list', [AdminBackupController::class, 'listBackups']);
        Route::post('/backup/create', [AdminBackupController::class, 'createBackup']);
        Route::delete('/backup/{filename}', [AdminBackupController::class, 'deleteBackup']);
        Route::post('/backup/{filename}/delete', [AdminBackupController::class, 'deleteBackup']);

        // Import
        Route::post('/import/employees', [AdminBackupController::class, 'importEmployees']);
        Route::post('/import/customers', [AdminBackupController::class, 'importCustomers']);
        Route::post('/import/tickets',         [AdminBackupController::class, 'importTickets']);
        Route::post('/import/ticket-members',  [AdminBackupController::class, 'importTicketMembers']);
        Route::post('/import/tickets/zip', [TicketMigrationController::class, 'importZip']);
        Route::post('/import/tickets/from-api', [TicketMigrationController::class, 'importFromApi']);
        Route::post('/import/resolution-days',    [AdminBackupController::class, 'importResolutionDays']);
        Route::post('/import/timesheet',           [AdminBackupController::class, 'importTimesheet']);
        Route::post('/import/customer-contacts',      [AdminBackupController::class, 'importCustomerContacts']);
        Route::post('/import/delivery-support',       [AdminBackupController::class, 'importDeliverySupport']);
        Route::post('/import/employee-qualification', [AdminBackupController::class, 'importEmployeeQualification']);

        // Failed Job Monitor
        Route::get('/failed-jobs', [AdminJobController::class, 'index']);
        Route::get('/failed-jobs/{uuid}', [AdminJobController::class, 'show']);
        Route::post('/failed-jobs/{uuid}/retry', [AdminJobController::class, 'retry']);
        Route::post('/failed-jobs/retry-all', [AdminJobController::class, 'retryAll']);
        Route::delete('/failed-jobs/{uuid}', [AdminJobController::class, 'destroy']);
        Route::post('/failed-jobs/{uuid}/delete', [AdminJobController::class, 'destroy']);
        Route::delete('/failed-jobs', [AdminJobController::class, 'clearAll']);
        Route::post('/failed-jobs/clear', [AdminJobController::class, 'clearAll']);
    });

    // ── SLA ────────────────────────────────────────────────────────────────
    Route::get('/tickets/{id}/sla',               [\App\Http\Controllers\SlaController::class, 'getTicketSla']);
    Route::post('/tickets/{id}/sla/meeting/start', [\App\Http\Controllers\SlaController::class, 'startMeeting']);
    Route::post('/tickets/{id}/sla/meeting/end',   [\App\Http\Controllers\SlaController::class, 'endMeeting']);

    // ── Meeting Templates (terikat per tiket) ───────────────────────────────────
    Route::get('/tickets/{id}/meeting-templates',            [\App\Http\Controllers\MeetingTemplateController::class, 'index']);
    Route::post('/tickets/{id}/meeting-templates',           [\App\Http\Controllers\MeetingTemplateController::class, 'store']);
    Route::put('/tickets/{id}/meeting-templates/{tplId}',    [\App\Http\Controllers\MeetingTemplateController::class, 'update']);
    Route::delete('/tickets/{id}/meeting-templates/{tplId}', [\App\Http\Controllers\MeetingTemplateController::class, 'destroy']);
    Route::post('/tickets/{id}/meeting-templates/{tplId}/delete', [\App\Http\Controllers\MeetingTemplateController::class, 'destroy']);

    // Admin-only SLA endpoints
    Route::get('/admin/sla/policies',          [\App\Http\Controllers\SlaController::class, 'getPolicies']);
    Route::post('/admin/sla/policies',         [\App\Http\Controllers\SlaController::class, 'storePolicy']);
    Route::put('/admin/sla/policies/{id}',     [\App\Http\Controllers\SlaController::class, 'updatePolicy']);
    Route::delete('/admin/sla/policies/{id}',  [\App\Http\Controllers\SlaController::class, 'destroyPolicy']);
    Route::post('/admin/sla/policies/{id}/delete', [\App\Http\Controllers\SlaController::class, 'destroyPolicy']);
    Route::get('/admin/sla/report',            [\App\Http\Controllers\SlaController::class, 'getReport']);

    // Notification sounds list (accessible to all authenticated users)
    Route::get('/notification-sounds', [AdminNotificationSoundController::class, 'list']);

    // ==================== ROLE & MENU MANAGEMENT ====================
    // HC-D63 (5 Okt 2026): SEMUA rute di blok ini dulu hanya `auth.session` — pegawai (bahkan customer) mana pun yang login
    // dapat memberi dirinya izin lewat API. Kini digerbang izin Management; `GET /my-menus` sengaja tetap terbuka.
    Route::get('/my-menus', [\App\Http\Controllers\MenuController::class, 'getMyMenus']);

    // Menu management
    Route::get('/menus',                                            [\App\Http\Controllers\MenuController::class, 'index'])->middleware('menu:management.roles,management.permissions');
    Route::get('/menus/all',                                        [\App\Http\Controllers\MenuController::class, 'allWithPermissions'])->middleware('menu:management.roles,management.permissions');
    Route::get('/menus/with-roles',                                 [\App\Http\Controllers\MenuController::class, 'withRoles'])->middleware('menu:management.roles,management.permissions');
    Route::post('/menus',                                           [\App\Http\Controllers\MenuController::class, 'store'])->middleware('menu:management.permissions');
    Route::put('/menus/{menuId}',                                   [\App\Http\Controllers\MenuController::class, 'update'])->middleware('menu:management.permissions');
    Route::delete('/menus/{menuId}',                                [\App\Http\Controllers\MenuController::class, 'destroy'])->middleware('menu:management.permissions');
    Route::post('/menus/{menuId}/delete',                           [\App\Http\Controllers\MenuController::class, 'destroy'])->middleware('menu:management.permissions');
    // Menu List → "Siapa yang punya akses": Menu Access dari sisi MENU (baca: roles ATAU permissions; ubah: roles).
    Route::prefix('menus/{menuId}/access')->whereNumber('menuId')->group(function () {
        $c = \App\Http\Controllers\Management\MenuRoleAccessController::class;
        Route::get('/',         [$c, 'show'])->middleware('menu:management.roles,management.permissions');
        Route::get('/history',  [$c, 'history'])->middleware('menu:management.roles,management.permissions');
        Route::post('/plan',    [$c, 'plan'])->middleware('menu:management.roles');
        Route::post('/apply',   [$c, 'apply'])->middleware('menu:management.roles');
        Route::post('/undo',    [$c, 'undo'])->middleware('menu:management.roles');
    });
    Route::put('/menus/{menuId}/roles/{roleId}',                    [\App\Http\Controllers\MenuController::class, 'updateRolePermission'])->middleware('menu:management.roles');
    Route::delete('/menus/{menuId}/roles/{roleId}',                 [\App\Http\Controllers\MenuController::class, 'removeRolePermission'])->middleware('menu:management.roles');
    Route::post('/menus/{menuId}/roles/{roleId}/delete',            [\App\Http\Controllers\MenuController::class, 'removeRolePermission'])->middleware('menu:management.roles');

    // Role management
    Route::get('/roles',                                            [\App\Http\Controllers\RoleController::class, 'index'])->middleware('menu:management.roles');
    Route::post('/roles',                                           [\App\Http\Controllers\RoleController::class, 'store'])->middleware('menu:management.roles');
    Route::get('/roles/{id}',                                       [\App\Http\Controllers\RoleController::class, 'show'])->middleware('menu:management.roles');
    Route::put('/roles/{id}',                                       [\App\Http\Controllers\RoleController::class, 'update'])->middleware('menu:management.roles');
    Route::delete('/roles/{id}',                                    [\App\Http\Controllers\RoleController::class, 'destroy'])->middleware('menu:management.roles');
    Route::post('/roles/{id}/delete',                               [\App\Http\Controllers\RoleController::class, 'destroy'])->middleware('menu:management.roles');
    Route::get('/roles/{id}/permissions',                           [\App\Http\Controllers\RoleController::class, 'permissions'])->middleware('menu:management.roles,management.permissions');
    Route::put('/roles/{id}/permissions/{menuId}',                  [\App\Http\Controllers\RoleController::class, 'updatePermission'])->middleware('menu:management.roles');
    Route::post('/roles/{id}/permissions/{menuId}/revoke',          [\App\Http\Controllers\RoleController::class, 'removePermission'])->middleware('menu:management.roles');
    Route::delete('/roles/{id}/permissions/{menuId}',               [\App\Http\Controllers\RoleController::class, 'removePermission'])->middleware('menu:management.roles');
    Route::post('/roles/{id}/permissions/{menuId}/delete',          [\App\Http\Controllers\RoleController::class, 'removePermission'])->middleware('menu:management.roles');
    Route::get('/roles/{id}/employees',                             [\App\Http\Controllers\RoleController::class, 'employees'])->middleware('menu:management.roles');

    // Menu Access per role (halaman penuh, HC-D63/D64): matriks, ringkasan perubahan, simpan massal, salin/bandingkan, riwayat + undo.
    Route::prefix('roles/{id}/menu-access')->middleware('menu:management.roles')->group(function () {
        Route::get('/',                          [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'matrix']);
        Route::post('/diff',                     [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'plan']);
        Route::post('/apply',                    [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'apply']);
        Route::get('/compare/{otherId}',         [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'compare']);
        Route::get('/copy-diff/{sourceId}',      [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'copyDiff']);
        Route::get('/history',                   [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'history']);
        Route::post('/history/{changeId}/undo',  [\App\Http\Controllers\Management\RoleMenuAccessController::class, 'undo']);
    });

    // Holiday management (Manajemen → Hari Libur)
    // Holidays apply to every employee, so only HR changes them: the Create / Edit / Delete boxes of management.holidays.
    Route::get('/management/holidays',         [\App\Http\Controllers\HolidayManagementController::class, 'index'])->middleware('menu:management.holidays');
    Route::post('/management/holidays',        [\App\Http\Controllers\HolidayManagementController::class, 'store'])->middleware('menu.can:management.holidays,create');
    Route::put('/management/holidays/{id}',    [\App\Http\Controllers\HolidayManagementController::class, 'update'])->middleware('menu.can:management.holidays,edit');
    Route::delete('/management/holidays/{id}', [\App\Http\Controllers\HolidayManagementController::class, 'destroy'])->middleware('menu.can:management.holidays,delete');
    Route::post('/management/holidays/{id}/delete', [\App\Http\Controllers\HolidayManagementController::class, 'destroy'])->middleware('menu.can:management.holidays,delete');

    // Employee ↔ Role assignment
    // Menentukan role seseorang = menentukan izinnya, jadi digate sama dengan
    // aksi master employee lain (mirror PATCH /employees/{id}/change-role).
    Route::get('/employees/{employeeId}/roles',                     [\App\Http\Controllers\RoleController::class, 'employeeRoles']);
    Route::post('/employees/{employeeId}/roles',                    [\App\Http\Controllers\RoleController::class, 'assignRoles'])->middleware('menu:master.employee.action');
    Route::put('/employees/{employeeId}/roles',                     [\App\Http\Controllers\RoleController::class, 'syncRoles'])->middleware('menu:master.employee.action');
    Route::delete('/employees/{employeeId}/roles/{roleId}',         [\App\Http\Controllers\RoleController::class, 'revokeRole'])->middleware('menu:master.employee.action');
    Route::post('/employees/{employeeId}/roles/{roleId}/delete',    [\App\Http\Controllers\RoleController::class, 'revokeRole'])->middleware('menu:master.employee.action');

    }); // end auth.session protected group
});

// ==================== JARVIES EXTERNAL API ====================
// Diakses dari server Jarvies menggunakan X-Api-Key header
// Tidak butuh browser session — autentikasi via JARVIES_API_KEY di .env
Route::middleware(['jarvies.api_key'])->prefix('jarvies')->group(function () {

    // --- Customer data (read-only) ---
    Route::get('/customers/{customerId}', [CustomerController::class, 'show']);
    Route::get('/customers/{customerId}/basic-data', [CustomerBasicDataController::class, 'show']);

    Route::get('/customers/{customerId}/contacts', [CustomerContactController::class, 'index']);
    Route::get('/customers/{customerId}/contacts/{contactId}', [CustomerContactController::class, 'show']);

    Route::get('/customers/{customerId}/addresses', [CustomerAddressController::class, 'index']);
    Route::get('/customers/{customerId}/addresses/{addressId}', [CustomerAddressController::class, 'show']);

    Route::get('/customers/{customerId}/identifications', [CustomerIdentificationController::class, 'index']);
    Route::get('/customers/{customerId}/identifications/{identificationId}', [CustomerIdentificationController::class, 'show']);

    Route::get('/customers/{customerId}/banks', [CustomerBankController::class, 'index']);
    Route::get('/customers/{customerId}/banks/{bankId}', [CustomerBankController::class, 'show']);

    Route::get('/customers/{customerId}/attachments', [CustomerAttachmentController::class, 'index']);
    Route::get('/customers/{customerId}/attachments/{attachmentId}', [CustomerAttachmentController::class, 'show']);
    Route::get('/customers/{customerId}/attachments/{attachmentId}/download', [CustomerAttachmentController::class, 'download']);

    // --- Tickets (customer-scoped) ---
    Route::get('/tickets', [TicketController::class, 'index']);
    Route::get('/tickets/{id}', [TicketController::class, 'show']);
    Route::get('/tickets/{ticketId}/messages', [TicketMessageController::class, 'index']);
    Route::post('/tickets/{ticketId}/customer-reply', [TicketMessageController::class, 'customerReply']);
    Route::put('/tickets/{ticketId}/messages/mark-all-read', [TicketMessageController::class, 'markAllRead']);

    // --- Staging tickets (submit new ticket from Jarvies) ---
    Route::post('/staging-tickets', [StagingTicketController::class, 'jarviesStore']);
    Route::get('/staging-tickets', [StagingTicketController::class, 'index']);
    Route::get('/staging-tickets/{id}', [StagingTicketController::class, 'show']);
    Route::get('/staging-tickets/{id}/preview-body', [StagingTicketController::class, 'previewBody']);
    Route::get('/staging-tickets/{id}/email-attachments', [StagingTicketController::class, 'emailAttachments']);
    Route::get('/staging-tickets/{id}/attachment-download', [StagingTicketController::class, 'emailAttachmentDownload']);

    // --- Customer Mandays (Jarvies customer-side) ---
    Route::get('/tickets/{ticketId}/mandays', [MandaysController::class, 'customerMandaysForJarvies']);
    Route::post('/tickets/{ticketId}/mandays/approve', [MandaysController::class, 'customerApproveMandays']);
    Route::post('/tickets/{ticketId}/mandays/reject', [MandaysController::class, 'customerRejectMandays']);
});

// ==================== EXTERNAL TICKET API ====================
// Requires X-Api-Key header matching EXTERNAL_TICKET_API_KEY
Route::middleware(['external.api_key'])->prefix('external')->group(function () {
    Route::get('/tickets', [TicketController::class, 'externalIndex']);
    Route::get('/tickets/create', [TicketController::class, 'storeExternalQuery']);
    Route::get('/tickets/{data}', [TicketController::class, 'storeExternal']);
});
